from drf_spectacular.utils import extend_schema
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet

from api.serializers import enveloper
from notifications.filters import ChannelFilter, MessageFilter, \
    SendingFilter, ScenarioFilter
from notifications.models import Message, Channel, Sending, Scenario
from notifications.serializers import MessageSerializer, SendingSerializer, \
    ChannelSerializer, SendingStatusSerializer, ScenarioSerializer
from notifications.services import MessageService, SendingService


@extend_schema(responses=enveloper(MessageSerializer), tags=['message'])
class MessageViewSet(ModelViewSet):
    """
    Работа с уведомлениями
    """
    queryset = Message.objects.all()
    serializer_class = MessageSerializer
    filterset_class = MessageFilter
    service_class = MessageService
    paginated_actions = ('list',)

    @extend_schema(responses=enveloper(MessageSerializer, True))
    def list(self, request, *args, **kwargs):
        return super().list(self, request, *args, **kwargs)

    def create(self, request, *args, **kwargs):
        result_data = self.service_class().create(request.data)

        return Response(data=result_data)

    @action(detail=False, methods=['patch'], url_path='bulk/remove')
    def bulk_remove(self, request, *args, **kwargs):
        result_data = self.service_class().delete(request.data)

        return Response(data=result_data)


@extend_schema(responses=enveloper(SendingSerializer), tags=['sending'])
class SendingViewSet(ModelViewSet):
    """
    Работа с отправками сообщений
    """
    queryset = Sending.objects.all()
    serializer_class = SendingSerializer
    filterset_class = SendingFilter
    service_class = SendingService
    paginated_actions = ('list',)

    @extend_schema(responses=enveloper(SendingSerializer, True))
    def list(self, request, *args, **kwargs):
        return super().list(self, request, *args, **kwargs)

    @action(detail=False, methods=['patch'], url_path='bulk/remove')
    def bulk_remove(self, request, *args, **kwargs):
        result_data = self.service_class().delete(request.data)

        return Response(data=result_data)

    @action(detail=False, methods=['patch'], url_path='status')
    def status(self, request, *args, **kwargs):
        service_class = self.service_class(
            serializer=SendingStatusSerializer,
            pk_name='uuid', pk_type=str)
        data = service_class.convert_dict_keys(request.data)
        data = service_class.update(data)

        return Response(data=data)


@extend_schema(responses=enveloper(ChannelSerializer), tags=['channel'])
class ChannelViewSet(ModelViewSet):
    """
    Работа с каналами расылок
    """
    queryset = Channel.objects.all()
    serializer_class = ChannelSerializer
    filterset_class = ChannelFilter
    paginated_actions = ('list',)

    @extend_schema(responses=enveloper(ChannelSerializer, True))
    def list(self, request, *args, **kwargs):
        return super().list(self, request, *args, **kwargs)


@extend_schema(responses=enveloper(ScenarioSerializer), tags=['scenario'])
class ScenarioViewSet(ModelViewSet):
    """
    Работа со сценариями отправок
    """
    queryset = Scenario.objects.all()
    serializer_class = ScenarioSerializer
    filterset_class = ScenarioFilter
    paginated_actions = ('list',)

    @extend_schema(responses=enveloper(ScenarioSerializer, True))
    def list(self, request, *args, **kwargs):
        return super().list(self, request, *args, **kwargs)
