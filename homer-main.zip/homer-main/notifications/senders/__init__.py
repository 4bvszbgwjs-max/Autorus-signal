from common import Senders
from notifications.senders.builtin_email import BuiltInEmailSender
from notifications.senders.core import SenderCore, SenderFactory
from notifications.senders.firebase_push import FirebasePushSender
from notifications.senders.idgtl import IdgtlSmsSender
from notifications.senders.notices import NoticesSender
from notifications.senders.retail_rocket import RetailRocketEmailSender
from notifications.senders.telegram import TelegramSender

senders_factory = SenderFactory()
senders_factory.register_builder(Senders.EMAIL_BUILTIN, BuiltInEmailSender)
senders_factory.register_builder(Senders.SMS_IDGTL, IdgtlSmsSender)
senders_factory.register_builder(Senders.PUSH_FIREBASE, FirebasePushSender)
senders_factory.register_builder(Senders.TELEGRAM, TelegramSender)
senders_factory.register_builder(Senders.NOTICES, NoticesSender)
senders_factory.register_builder(Senders.EMAIL_RETAILROCKET,
                                 RetailRocketEmailSender)
