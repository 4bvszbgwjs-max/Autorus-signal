import logging
import uuid

from notifications.senders.core import SenderCore

logger = logging.getLogger(__name__)


class FirebasePushSender(SenderCore):
    destination_field_name = 'applicationFirebaseToken'

    def send(self, **kwargs) -> tuple[bool, int] or tuple[bool, None]:
        """
        Sends a push message via fcm.googleapis.com
        :param message: The message being sent
        :param extra_params: Additional parameters for sending notifications
        :return: result: bool, message id: str
        """
        message = kwargs.get('message')
        extra_params = kwargs.get('extra_params', {})
        collapse_key = extra_params.get('collapse_key', None)
        priority = extra_params.get('priority', 10)
        time_to_live = extra_params.get('time_to_live', 3600)
        data_score = extra_params.get('data_score', '3x1')
        click_action = extra_params.get('click_action', 'arus_notification')
        message_id = uuid.uuid1()
        data = {
            'to': message.destination,
            'collapse_key': collapse_key,
            'priority': priority,
            'time_to_live': time_to_live,
            'data': {
                'score': data_score,
                'title': message.subject,
                'body': message.content
            },
            'notification': {
                'title': message.subject,
                'body': message.content,
                'sound': 'default',
                'click_action': click_action
            }
        }

        try:
            response = self.transport.send(data=data)

            if response.ok:
                logger.debug(
                    f'The push notify was sent to {message.destination}')
                response_data = response.json()
                results = response_data.get('results', [])

                if len(results) > 0:
                    message_id = results[0].get('message_id', message_id)

                return True, message_id

            else:
                return False, None

        except Exception:
            logger.exception('Send push notify failed')

            return False, None
