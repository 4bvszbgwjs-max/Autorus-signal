import logging

import requests

from notifications.senders.transports.core import SenderTransport

logger = logging.getLogger(__name__)


class SenderTransportRequests(SenderTransport):
    connection: requests.Session or None = None
    timeout: tuple[int, int] = (3, 6)
    headers: dict = {}

    def open_connection(self) -> requests.Session:
        try:
            user = self.username
            password = self.password
            session = requests.Session()
            session.headers.update(self.headers)
            session.auth = (user, password) if user else None
            self.connection = session

            return session

        except Exception:
            self.connection = None
            logger.debug(f'Connection to {self.url} could not be established')

    def close_connection(self, confirm_delivery=False):
        try:
            if self.connection:
                self.connection.close()
        finally:
            self.connection = None

    def check_connection(self) -> bool:
        return bool(self.connection)

    def send(self, **kwargs) -> requests.Response or None:
        data = kwargs.get('data', None)
        params = kwargs.get('params', None)
        url = self.url
        method = self.method
        timeout = self.timeout

        if self.connection is None:
            self.open_connection()

            if self.connection is None:
                return

        try:
            response = self.connection.request(
                method, url, json=data, timeout=timeout, params=params)

            return response

        except Exception:
            logger.exception('Send data via requests failed')
