from abc import ABC, abstractmethod
from urllib.parse import urlparse

from common.services import Factory


class SenderTransport(ABC):
    url: str
    method: str
    scheme: str
    netloc: str
    path: str
    params: str
    query: str
    fragment: str
    username: str or None
    password: str or None
    hostname: str or None
    port: int or None

    def __init__(self, **kwargs):
        url = kwargs.pop('url')
        self.method: str = kwargs.pop('method', 'get')
        self._parse_url(url)
        for param_name, param_value in kwargs.items():
            setattr(self, param_name, param_value)

        self.open_connection()

    def _parse_url(self, url: str) -> None:
        parse_result = urlparse(url)
        self.scheme = parse_result.scheme
        self.netloc = parse_result.netloc
        self.path = parse_result.path
        self.params = parse_result.params
        self.query = parse_result.query
        self.fragment = parse_result.fragment
        self.username = parse_result.username
        self.password = parse_result.password
        self.hostname = parse_result.hostname
        self.port = parse_result.port
        self.url = parse_result.geturl()

    @property
    @abstractmethod
    def connection(self):
        ...

    @abstractmethod
    def open_connection(self):
        ...

    @abstractmethod
    def close_connection(self):
        ...

    def reopen_connection(self):
        self.close_connection()
        self.open_connection()

        return self.connection

    @abstractmethod
    def check_connection(self):
        ...

    @abstractmethod
    def send(self, **kwargs):
        ...


class SenderTransportFactory(Factory):
    ...
