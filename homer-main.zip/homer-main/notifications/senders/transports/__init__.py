from notifications.senders.transports.core import SenderTransportFactory
from notifications.senders.transports.http import SenderTransportRequests
from notifications.senders.transports.rmq import SenderTransportRMQ

senders_transport_factory = SenderTransportFactory()
senders_transport_factory.register_builder('http', SenderTransportRequests)
senders_transport_factory.register_builder('https', SenderTransportRequests)
senders_transport_factory.register_builder('amqp', SenderTransportRMQ)
