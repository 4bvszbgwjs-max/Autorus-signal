import json
import logging

import pika
from pika import PlainCredentials

from notifications.senders.transports.core import SenderTransport

logger = logging.getLogger(__name__)


class SenderTransportRMQ(SenderTransport):
    connection: pika.BlockingConnection or None = None
    heartbeat: int = 360
    vhost: str = '/'
    channel: pika.BlockingConnection.channel or None = None
    delivery_tag: int = 0
    confirm_delivery: bool = False
    exchange: str
    routing_key: str = ''
    properties: pika.BasicProperties = pika.BasicProperties(delivery_mode=2)

    def open_connection(self) -> pika.BlockingConnection:
        try:
            user = self.username
            password = self.password
            host = self.hostname
            vhost = self.vhost
            port = self.port
            heartbeat = self.heartbeat
            credentials = PlainCredentials(user, password) if user else None

            connection_parameters = pika.connection.ConnectionParameters(
                host=host, virtual_host=vhost, port=port,
                credentials=credentials, heartbeat=heartbeat)
            self.connection = pika.BlockingConnection(connection_parameters)

            return self.connection

        except Exception:
            self.connection = None
            logger.debug(f'Connection to {self.url} could not be established')

    def close_connection(self, confirm_delivery=False):
        try:
            if self.connection:
                self.connection.close()
        finally:
            self.connection = None

    def check_connection(self) -> bool:
        return bool(self.connection) and self.connection.is_open

    def open_channel(self) -> pika.BlockingConnection.channel or None:
        try:
            if not self.check_connection():
                self.reopen_connection()

            self.channel = self.connection.channel()

            return self.channel

        except Exception:
            self.channel = None
            logger.exception('Failed to open channel')

    def close_channel(self):
        delivery_tag = self.delivery_tag
        confirm_delivery = self.confirm_delivery

        try:
            if self.channel:
                if confirm_delivery:
                    self.channel.basic_ack(delivery_tag=delivery_tag,
                                           multiple=True)
                if self.channel.is_open:
                    self.channel.close()

        finally:
            self.channel = None

    def reopen_channel(self):
        self.close_channel()
        self.open_channel()

    def send(self, **kwargs) -> bool:
        self.reopen_channel()

        if self.channel is None:
            return False

        data = kwargs.get('data', '')
        channel = self.channel
        exchange = self.exchange
        routing_key = self.routing_key
        properties = self.properties

        try:
            channel.confirm_delivery()
            body = bytes(json.dumps(data, ensure_ascii=False), 'utf-8')
            channel.basic_publish(exchange=exchange, routing_key=routing_key,
                                  body=body, mandatory=True,
                                  properties=properties)

            return True

        except Exception:
            logger.exception('Send data via requests failed')

            return False
