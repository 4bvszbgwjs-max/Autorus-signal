from abc import ABC, abstractmethod
from urllib.parse import urlparse

import notifications.senders.transports as transports
from common.services import Factory


class SenderCore(ABC):
    transport: transports.core.SenderTransport or None = None

    def __init__(self, **kwargs):
        url = kwargs.get('url', None)

        if url:
            parse_result = urlparse(url)
            scheme = parse_result.scheme
            self.transport: transports.core.SenderTransport = \
                transports.senders_transport_factory.create(scheme, **kwargs)

    @property
    @abstractmethod
    def destination_field_name(self) -> str:
        ...

    @staticmethod
    def send(self, **kwargs) -> tuple:
        ...


class SenderFactory(Factory):
    ...
