import logging
import uuid

from notifications.senders.core import SenderCore

logger = logging.getLogger(__name__)


class IdgtlSmsSender(SenderCore):
    destination_field_name = 'phone'

    def send(self, **kwargs) -> tuple[bool, int] or tuple[bool, None]:
        """
        Sends a message via i-dgtl.ru
        :param message: The message being sent
        :return: result: bool, message uuid: str
        """
        message = kwargs.get('message')
        sender_name = getattr(self, 'sender_name', 'autorus.ru')
        message_uuid = uuid.uuid1()
        data = [{'channelType': 'SMS',
                 'senderName': sender_name,
                 'destination': message.destination,
                 'content': message.content}]

        try:
            response = self.transport.send(data=data)

            if response.ok:
                logger.debug(f'The sms was sent to {message.destination}')
                response_data = response.json()
                items = response_data.get('items', [])

                if len(items) > 0:
                    message_uuid = items[0].get('messageUuid', message_uuid)

                return True, message_uuid

            else:
                return False, None

        except Exception:
            logger.exception('Send sms failed')

            return False, None
