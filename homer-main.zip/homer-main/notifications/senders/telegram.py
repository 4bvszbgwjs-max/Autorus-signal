import logging

import telebot

from notifications.senders.core import SenderCore

logger = logging.getLogger(__name__)


class TelegramSender(SenderCore):
    destination_field_name = 'phone'

    def send(self, **kwargs) -> tuple[bool, int] or tuple[bool, None]:
        """
        Sends a message via message.channel_type.config.vendor
        :param message: The message being sent
        :return: result: bool, message uuid: str
        """
        message = kwargs.get('message')
        config = message.channel.config
        token = config['token']
        destination = message.destination
        text = message.content

        try:
            bot = telebot.TeleBot(token)
            result = bot.send_message(destination, text)
            logger.debug(
                f'The telegram {text[::50]} was sent to {destination}')

            return True, result.message_id

        except Exception:
            logger.exception('Send telegram failed')

            return False, None
