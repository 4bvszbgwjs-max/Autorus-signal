import logging
import uuid

from notifications.senders.core import SenderCore

logger = logging.getLogger(__name__)


class NoticesSender(SenderCore):
    destination_field_name = 'phone'

    def send(self, **kwargs) -> tuple[bool, int] or tuple[bool, None]:
        """
        Create a new message in Notices services
        :param: sending: notifications.models.Sending: The message being sent
        :return: result: bool, message uuid: str
        """
        sending = kwargs.get('message')

        if sending.message:
            message_uuid = str(sending.message.uuid)
            data = [{'uuid': message_uuid,
                     'subject': sending.subject,
                     'recipientId': sending.message.recipientId,
                     'content': sending.content,
                     'type': sending.message.type,
                     'tags': sending.message.tags,
                     'metadata': sending.message.metadata}]
        else:
            message_uuid = str(uuid.uuid1())
            data = [{'uuid': message_uuid,
                     'subject': sending.subject,
                     'recipientId': sending.destination,
                     'content': sending.content}]

        try:
            result = self.transport.send(data=data)
            logger.debug(f'The notice was sent to {sending.destination}')

            return result, message_uuid

        except Exception:
            logger.exception('Creating notice failed')

            return False, None

    def send_bulk(self, **kwargs):
        sendings = kwargs.get('messages')
        data = []
        uuids: list[str] = []
        for sending in sendings:
            if sending.message:
                message_uuid = str(sending.message.uuid)
                uuids.append(message_uuid)
                data.append({'uuid': message_uuid,
                             'subject': sending.subject,
                             'recipientId': sending.message.recipientId,
                             'content': sending.content,
                             'type': sending.message.type,
                             'tags': sending.message.tags,
                             'metadata': sending.message.metadata})
            else:
                message_uuid = str(uuid.uuid1())
                uuids.append(message_uuid)
                data.append({'uuid': message_uuid,
                             'subject': sending.subject,
                             'recipientId': sending.destination,
                             'content': sending.content})

        try:
            result = self.transport.send(data=data)
            logger.debug(f'The notice was sent to {sendings[0].destination}')

            return result, uuids

        except Exception:
            logger.exception('Creating notice failed')

            return False, None
