import logging
import uuid

from notifications.senders.core import SenderCore

logger = logging.getLogger(__name__)


class RetailRocketEmailSender(SenderCore):
    destination_field_name = 'email'

    def send(self, **kwargs) -> tuple[bool, int] or tuple[bool, None]:
        """
        Sends a message via retailrocket.ru
        :param message: The message being sent
        :return: result: bool, message uuid: str
        """
        try:
            sending = kwargs.get('message')
            message = sending.message
            metadata = message.metadata
            message_uuid = uuid.uuid1()
            email = sending.destination
            api_key = getattr(self.transport, 'apikey')
            params = {'apikey': api_key, 'email': email}
            campaign_id = metadata.get('campaignId', None)

            if campaign_id:
                self.transport.url += f'/{campaign_id}'

            response = self.transport.send(data=metadata, params=params)

            if response.ok:
                logger.debug(f'The email was sent to {email}')

                return True, message_uuid

            else:
                return False, None

        except Exception:
            logger.exception('Send email failed')

            return False, None
