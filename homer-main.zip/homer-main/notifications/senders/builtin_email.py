import logging
import smtplib
import ssl
import uuid
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from notifications.senders.core import SenderCore

logger = logging.getLogger(__name__)


class BuiltInEmailSender(SenderCore):
    destination_field_name = 'email'

    @staticmethod
    def send(**kwargs) -> tuple[bool, str] or tuple[bool, None]:
        """
        Sends a message via message.channel_type.config.vendor
        :param message: The message being sent
        :return: result: bool, message uuid: str
        """
        message = kwargs.get('message')
        message_id = str(uuid.uuid1())
        config = message.channel.config
        sender_email = config['email']
        receiver_email = message.destination
        server = config['server']
        port = config['port']
        user = config['user']
        password = config['password']
        is_ssl = config['ssl']

        msg = MIMEMultipart("alternative")
        msg["Subject"] = message.subject
        msg["From"] = sender_email
        msg["To"] = receiver_email

        text = message.content
        html = message.content

        part1 = MIMEText(text, "plain")
        part2 = MIMEText(html, "html")

        msg.attach(part1)
        msg.attach(part2)
        smtp_client = None

        try:
            if is_ssl:
                context = ssl.create_default_context()
                smtp_client = smtplib.SMTP_SSL(server, port, context=context)

            else:
                smtp_client = smtplib.SMTP(server, port)

            smtp_client.ehlo()
            smtp_client.starttls()
            smtp_client.ehlo()
            smtp_client.login(user, password)
            smtp_client.sendmail(sender_email, receiver_email, msg.as_string())
            logger.debug(f'The mail was sent to {receiver_email}')

            return True, message_id

        except Exception:
            logger.exception('Send mail failed')

            return False, None

        finally:
            smtp_client.close()
