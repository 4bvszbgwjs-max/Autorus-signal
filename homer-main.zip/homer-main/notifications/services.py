import json
import logging
from functools import lru_cache

from django.db import transaction, models
from django.db.models import Count, Min, F
from django.utils import timezone

import notifications.senders as senders
from common.enums import MessageStatuses, Senders, MessageTypes
from common.services import Service, ServiceBatchFetch
from common.utils import get_section_data_by_path
from notifications.models import Message, Channel, Sending, Scenario
from notifications.senders import SenderCore
from notifications.serializers import ScenarioSerializer, SendingSerializer, \
    MessageSerializer, ChannelSerializer
from recipients.models import Recipient
from recipients.services import RecipientService

logger = logging.getLogger(__name__)


class ServiceMixin:
    model: models.Model
    batch_fetcher: ServiceBatchFetch
    keys_map: dict = {'messageUuid': 'uuid'}

    def set_expiration(self) -> bool:
        timestamp = timezone.now()
        self.batch_fetcher.set_filter(expire__lte=timestamp,
                                      status__lt=MessageStatuses.QUEUED)

        for batch in self.batch_fetcher.fetch():
            items = []

            for item in batch:
                item.status = MessageStatuses.EXPIRED
                items.append(item)

            self.model.objects.bulk_update(items, ['status'])

        return True

    def get_statistic_by_status(self) -> list[tuple[tuple[str], int]]:
        messages_by_status = \
            self.model.objects.values('status').annotate(total=Count('id'))
        all_statuses = {MessageStatuses(status).name: 0 for status in
                        MessageStatuses.values}
        all_statuses.update(
            {MessageStatuses(item['status']).name: item['total']
             for item in messages_by_status})
        result = [((item[0],), item[1]) for item in all_statuses.items()]

        return result

    def convert_dict_keys(self, data: dict or list) -> dict or list:
        if isinstance(data, dict):
            new_data = {}
            for item in data.items():
                value = self.convert_dict_keys(item[1])
                key = self.keys_map.get(item[0], item[0])
                new_data[key] = value

            return new_data

        elif isinstance(data, list):
            new_data = []
            for item in data:
                new_item = self.convert_dict_keys(item)
                new_data.append(new_item)

            return new_data

        return data


class ChannelService(Service):
    model = Channel
    serializer = ChannelSerializer
    senders: Senders = Senders
    pk_name: str = 'code'
    pk_type: type = str

    @classmethod
    @lru_cache
    def get_cached(cls, code: str) -> Channel:
        """
        Получение канала по его коду.
        Кэшированная функция
        :param code: Код канала (первичный ключ)
        :return: Channel
        """
        result = cls.model.objects.get(code=code)

        return result


class ScenarioService(Service):
    model = Scenario
    serializer = ScenarioSerializer

    @staticmethod
    def _is_condition_available(fields: list[str], recipient: Recipient,
                                condition_type: str) -> bool:
        result = True

        if recipient:
            for field in fields:
                value = getattr(recipient, field)

                if condition_type == 'notNone' and not value:
                    result = False

                elif condition_type == 'equalTrue' and value is not True:
                    result = False

                elif condition_type == 'equalFalse' and value is not False:
                    result = False

        elif fields is not None and len(fields) > 0:
            result = False

        return result

    @classmethod
    def check_channels(cls, channels: list[dict],
                       recipient: Recipient, break_it: bool = False) -> set:
        result = set()

        for channel in channels:
            if not channel['isActive']:
                continue

            conditions = channel['fieldsConditions']
            conditions_result = []

            for condition_type, fields in conditions.items():
                condition_available = cls._is_condition_available(
                    fields, recipient, condition_type)
                conditions_result.append(condition_available)

            if all(conditions_result):
                result.add(channel['channel'])

                if break_it:
                    break

        return result

    @classmethod
    def get_available_channels(cls, scenario: Scenario,
                               recipient: Recipient) -> list[set[str]]:
        scenario_data = cls.serializer(scenario).data
        first_of_channels = scenario_data.get('channelsFirstOf')
        every_of_channels = scenario_data.get('channelsEveryOf')
        result = set()
        channels = cls.check_channels(first_of_channels, recipient, True)
        result.update(channels)
        channels = cls.check_channels(every_of_channels, recipient, False)
        result.update(channels)

        return list(result)

    @classmethod
    @lru_cache
    def get_scenario_by_default(
            cls, message_type: MessageTypes) -> Scenario or None:
        scenarios = Scenario.objects.filter(
            messageType=message_type, byDefault=True)
        if scenarios.count() > 0:
            return scenarios[0]

        return None

    @classmethod
    def get_message_scenario(cls, message: Message) -> Scenario or None:
        result = None

        if message.scenario is not None:
            result = message.scenario

        if message.type is not None and not result:
            message_type = MessageTypes(message.type)
            result = cls.get_scenario_by_default(message_type)

        return result

    @classmethod
    def get_channel_param(cls, scenario: Scenario,
                          channel: Channel) -> dict or None:
        result = None

        if scenario is not None:
            available_channels = \
                [item for item in
                 scenario.channelsEveryOf + scenario.channelsFirstOf if
                 item['isActive'] and item['channel'] == channel.code]

            if len(available_channels) == 0:
                return result

            result = available_channels[0]

        return result


class SendingService(Service, ServiceMixin):
    model = Sending
    serializer = SendingSerializer
    BULK_SENDING_CHANNELS = ['Notices']

    @classmethod
    def get_destination(cls, message: Message,
                        sender: SenderCore,
                        config: dict,
                        recipient: Recipient) -> str or None:
        metadata = message.metadata
        result = None
        config_field_path = None
        config_field = None
        sender_field_name = sender.destination_field_name

        if config:
            config_field_path = config.get('destinationFieldPath', None)
            config_field = config.get('destinationFieldPath', None)

        if config_field_path:
            result = get_section_data_by_path(metadata, config_field_path)

        elif recipient and config_field:
            result = getattr(recipient, config_field)

        elif recipient and sender_field_name:
            result = getattr(recipient, sender_field_name)

        return result

    @classmethod
    def get_content(cls, message: Message, config: dict) -> str or None:
        content_field = None

        if config:
            content_field = config.get('contentField', None)

        if content_field:
            result = getattr(message, content_field)

        else:
            result = message.content

        return result

    def put_new_to_queue(self, map_channel_tasks: dict) -> bool:
        message_service = MessageService()
        timestamp = timezone.now()
        self.batch_fetcher.set_filter(
            status__lt=MessageStatuses.QUEUED,
            expire__gte=timestamp,
            mustBeSend__lte=timestamp,
        )
        self.batch_fetcher.set_exclude_filter(destination='')
        bulk_messages = []

        for batch in self.batch_fetcher.fetch():
            sendings_to_update = []
            messages_to_update = []

            for sending in batch.prefetch_related('channel', 'message'):
                if sending.channel.name in SendingService.BULK_SENDING_CHANNELS:
                    bulk_messages.append({'id': sending.id})
                else:
                    message = {'id': sending.id}
                    map_channel_tasks[sending.channel.sender].delay(**message)
                sending.status = MessageStatuses.QUEUED
                sendings_to_update.append(sending)

                if sending.message:
                    sending.message.status = MessageStatuses.QUEUED
                    messages_to_update.append(sending.message)

            if bulk_messages:
                messages = {'messages': bulk_messages}
                map_channel_tasks[ChannelService.senders.NOTICES].delay(**messages)

            self._bulk_update(sendings_to_update, ['status'])
            message_service._bulk_update(messages_to_update, ['status'])
            bulk_messages = []

        return True

    @classmethod
    def get_statistic_by_channel(cls) -> list[tuple[tuple[str], int]]:
        sendings = cls.model.objects.values('channel__code').annotate(
            total=Count('id'))
        all_channels = {channel: 0 for channel in
                        Channel.objects.values_list('code', flat=True)}
        all_channels.update({item['channel__code']: item['total']
                             for item in sendings})
        result = [((item[0],), item[1]) for item in all_channels.items()]

        return result

    @staticmethod
    def send(message: Sending) -> bool:
        sender = senders.senders_factory.create(
            message.channel.sender, **message.channel.config)
        result, message_uuid = sender.send(message=message)

        if result:
            message.uuid = message_uuid
            message.status = MessageStatuses.SENT
            message.save(update_fields=('uuid', 'status'))

        return result

    @staticmethod
    def send_bulk(messages) -> bool:
        message = messages[0]
        sender = senders.senders_factory.create(
            message.channel.sender, **message.channel.config)
        results, message_uuids = sender.send_bulk(messages=messages)

        if results:
            for i, message_uuid in enumerate(message_uuids):
                messages[i].uuid = message_uuid
                messages[i].status = MessageStatuses.SENT
                messages[i].save(update_fields=('uuid', 'status'))
            return True
        return False

    @staticmethod
    def send_by_id(message_id: int) -> bool:
        message = Sending.objects.get(pk=message_id)
        result = SendingService.send(message)

        return result

    @staticmethod
    def send_by_ids(message_ids) -> bool:
        messages = Sending.objects.filter(id__in=message_ids)
        result = SendingService.send_bulk(messages)

        return result

    @classmethod
    def create_from_message(cls, message: Message,
                            recipient: Recipient) -> list[dict]:
        result = []
        scenario = message.scenario

        for message_channel in message.channels:
            channel = ChannelService.get_cached(message_channel)
            sender = senders.senders_factory.create(channel.sender)
            scenario_config = ScenarioService.get_channel_param(
                scenario, channel)
            destination = cls.get_destination(
                message=message,
                sender=sender,
                config=scenario_config,
                recipient=recipient
            )
            if not destination:
                continue

            content = cls.get_content(message=message, config=scenario_config)
            new_sending = {
                'channel': message_channel,
                'message': message.id,
                'expire': message.expire,
                'mustBeSend': message.mustBeSend,
                'subject': message.subject,
                'content': content,
                'destination': destination
            }
            result.append(new_sending)

        return result


class MessageService(Service, ServiceMixin):
    model = Message
    serializer = MessageSerializer

    def create_sendings_from_new_messages(self) -> bool:
        timestamp = timezone.now()
        sending_service = SendingService()
        self.batch_fetcher.set_filter(
            expire__gte=timestamp,
            status=MessageStatuses.NEW
        )

        for batch in self.batch_fetcher.fetch():
            recipient_ids = [message.recipientId for message in batch]
            recipients = RecipientService.get_pk_map(recipient_ids)
            sendings_to_create = []
            messages_to_update = []

            for message in batch.prefetch_related('scenario'):
                message.status = MessageStatuses.READY
                messages_to_update.append(message)
                recipient_id = message.recipientId
                recipient = recipients.get(recipient_id, None)
                scenario = ScenarioService.get_message_scenario(message)

                if scenario and message.type != scenario.messageType:
                    message.type = scenario.messageType

                if scenario and message.scenario != scenario:
                    message.scenario = scenario

                if scenario:
                    channels = ScenarioService.get_available_channels(
                        scenario, recipient)

                    if len(channels) > 0:
                        message.channels = channels

                if len(message.channels) == 0:
                    message.status = MessageStatuses.UNSENT

                new_sendings_data = SendingService.create_from_message(
                    message=message, recipient=recipient)
                sendings_to_create.extend(new_sendings_data)

            try:
                with transaction.atomic():
                    sending_service.create(sendings_to_create)
                    self._bulk_update(
                        messages_to_update,
                        ['status', 'scenario', 'channels', 'type']
                    )

            except Exception as ex:
                logger.exception('Failed to create sendings!', exc_info=ex)

        return True

    def periodic_status_update(self) -> bool:
        self.batch_fetcher.set_filter(status__lt=F('sendings__status'))

        for batch in self.batch_fetcher.fetch():
            messages = batch.annotate(new_status=Min('sendings__status'))
            messages_to_update = []
            for message in messages:
                message.status = message.new_status
                messages_to_update.append(message)

            self._bulk_update(messages_to_update, ['status'])

        return True

    def delete_expire(self) -> bool:
        timestamp = timezone.now()
        self.batch_fetcher.set_filter(expire__lte=timestamp)
        self.batch_fetcher.values_fields = ('uuid',)

        for batch in self.batch_fetcher.fetch():
            self.delete(batch)

        return True

    def delete(self, data: list) -> bool:
        sending_service = SendingService()
        messages_uuids = [item.get('uuid') for item in data]
        self.batch_fetcher.set_filter(uuid__in=messages_uuids)

        for batch in self.batch_fetcher.fetch():
            messages_ids = batch.values_list('id', flat=True)

            try:
                with transaction.atomic():
                    sending_service.model.objects. \
                        filter(message_id__in=messages_ids).delete()
                    self.model.objects.filter(id__in=messages_ids).delete()

            except Exception as ex:
                logger.exception('Failed to create sendings!', exc_info=ex)

        return True

    def consume(self, payload: str) -> bool:
        data = json.loads(payload)
        result = bool(self.create(data))

        return result

    def create(self, data: dict or list) -> dict:
        data = [data, ] if isinstance(data, dict) else data
        all_ids = [item['eventId'] for item in data if item.get('eventId')]
        all_objects = self.model.objects.filter(eventId__in=all_ids)
        existing_objects = {getattr(item, 'eventId'): item for item
                            in all_objects}
        data_for_create = []

        for item in data:
            event_id = item.get('eventId', None)
            instance = existing_objects.get(event_id, None)

            if not instance:
                data_for_create.append(item)

            if not event_id:
                item.pop('eventId', None)

        return super().create(data_for_create)
