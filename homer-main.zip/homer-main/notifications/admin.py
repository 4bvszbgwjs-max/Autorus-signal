from django.contrib import admin

from common import CoreModelAdmin
from notifications.models import Message, Sending, Channel, Scenario

service_fields = ('Служебные', {
    'fields': ('id', 'createdAt', 'updatedAt', 'isDeleted',),
})


@admin.register(Message)
class MessageAdmin(CoreModelAdmin):
    list_display = ('__str__', 'type', 'scenario', 'mustBeSend', 'expire',
                    'subject', 'status', 'eventId', 'createdAt', 'updatedAt',
                    'isDeleted',)
    fieldsets = (
        ('Основное', {
            'fields': ('uuid', 'eventId', 'type', 'status', 'mustBeSend',
                       'expire', 'subject', 'recipientId', 'scenario',
                       'channels', 'tags', 'metadata',)
        }),
        ('Содержание', {
            'fields': ('shortContent', 'content', 'htmlContent',)
        }),
        CoreModelAdmin.service_fields,
    )
    readonly_fields = CoreModelAdmin.readonly_fields
    list_filter = Message.list_filter
    search_fields = Message.search_fields


@admin.register(Sending)
class SendingAdmin(CoreModelAdmin):
    list_display = ('__str__', 'mustBeSend', 'expire', 'subject',
                    'status', 'destination', 'channel', 'createdAt',
                    'updatedAt', 'isDeleted',)
    fieldsets = (
        ('Основное', {
            'fields': ('message', 'uuid', 'mustBeSend', 'expire', 'status',
                       'subject', 'destination', 'channel',
                       'content',)
        }), CoreModelAdmin.service_fields,
    )
    readonly_fields = CoreModelAdmin.readonly_fields
    list_filter = Sending.list_filter
    search_fields = Sending.search_fields


@admin.register(Channel)
class ChannelAdmin(CoreModelAdmin):
    list_display = ('name', 'code', 'sender', 'createdAt', 'updatedAt',
                    'isDeleted',)
    fieldsets = (
        ('Основное', {
            'fields': ('name', 'code', 'sender', 'config',)
        }), CoreModelAdmin.service_fields,
    )
    readonly_fields = CoreModelAdmin.readonly_fields
    list_filter = Channel.list_filter
    search_fields = Channel.search_fields
    prepopulated_fields = {"code": ("name",)}


@admin.register(Scenario)
class ScenarioAdmin(CoreModelAdmin):
    list_display = ('__str__', 'messageType', 'createdAt', 'updatedAt',
                    'byDefault', 'isDeleted',)
    fieldsets = (
        ('Основное', {
            'fields': ('__str__', 'uuid', 'messageType', 'description',
                       'byDefault',)
        }), ('Каналы: Первый из', {
            'fields': ('channelsFirstOf',)
        }), ('Каналы: Каждый из', {
            'fields': ('channelsEveryOf',)
        }), CoreModelAdmin.service_fields,
    )
    readonly_fields = CoreModelAdmin.readonly_fields
    list_filter = Scenario.list_filter
    search_fields = Scenario.search_fields
