import uuid as uuid
from functools import lru_cache

from django.apps import apps
from django.db import models
from django.utils import timezone
from django_jsonform.models.fields import JSONField

from common import CoreModel, MessageStatuses, MessageTypes, \
    Senders


@lru_cache
def channels_as_choices() -> list[dict]:
    channel_model = apps.get_model('notifications', 'Channel')
    channels = list(channel_model.objects.values(
        title=models.F('name'), value=models.F('code')))

    return channels


@lru_cache
def scenario_config_schema() -> dict:
    destination_field_choices = (
        {'title': 'Телефон', 'value': 'phone'},
        {'title': 'Эл. почта', 'value': 'email'},
        {'title': 'Push токен', 'value': 'applicationFirebaseToken'},
    )
    content_field_choices = (
        {'title': 'Короткое', 'value': 'shortContent'},
        {'title': 'Обычное', 'value': 'content'},
        {'title': 'HTML', 'value': 'htmlContent'},
    )
    destination_fields = ('phone', 'email', 'applicationFirebaseToken',)
    confirm_fields = ('isSubscribe', 'isConfirmed', 'isPhoneConfirmed',)
    schema = {
        'title': 'Каналы',
        'type': 'array',
        'items': {
            'type': 'object',
            'properties': {
                'channel': {
                    'type': 'string',
                    'title': 'Канал',
                    'help_text': 'Выберите канал доставки',
                    'choices': channels_as_choices()
                },
                "isActive": {
                    "type": "boolean",
                    "title": "Активен"
                },
                'destinationField': {
                    'type': 'string',
                    'title': 'Поле <<назначение>>',
                    'help_text': 'Выберите поле, которое является назначением '
                                 'для данного канала',
                    'choices': destination_field_choices
                },
                'contentField': {
                    'type': 'string',
                    'title': 'Поле <<содержание>>',
                    'help_text': 'Выберите поле <<содержание>> '
                                 'для данного канала',
                    'choices': content_field_choices
                },
                'destinationFieldPath': {
                    'type': 'string',
                    'title': 'Путь к полю назначения',
                    'help_text': 'Или укажите к нему путь в секции <metadata>'
                },
                'fieldsConditions': {
                    'type': 'object',
                    'title': 'Условия полей',
                    'properties': {
                        'notNone': {
                            'type': 'list',
                            'title': 'Заполнены',
                            'items': {
                                'type': 'string',
                                'choices': destination_fields
                            }
                        },
                        'equalTrue': {
                            'type': 'list',
                            'title': '= <Истина>',
                            'items': {
                                'type': 'string',
                                'choices': confirm_fields
                            }
                        },
                        'equalFalse': {
                            'type': 'list',
                            'title': '= <Ложь>',
                            'items': {
                                'type': 'string',
                                'choices': confirm_fields
                            }
                        }
                    }
                }
            }
        }
    }
    return schema


@lru_cache
def channel_config_schema() -> dict:
    http_method_choices = ('get', 'post', 'patch', 'put',)
    schema = {
        'type': 'object',
        'properties': {
            'url': {
                'type': 'string'
            },
            'method': {
                'type': 'string',
                'choices': http_method_choices,
            },
            'headers': {
                'type': 'object',
                'properties': {},
                'additionalProperties': {'type': 'string'}
            }
        },
        'additionalProperties': {
            'type': 'string'
        }
    }
    return schema


@lru_cache
def message_channels_schema() -> dict:
    schema = {
        'type': 'array',
        'items': {
            'type': 'string',
            'choices': channels_as_choices()

        }
    }
    return schema


@lru_cache
def array_of_string_schema() -> dict:
    schema = {
        'type': 'array',
        'items': {
            'type': 'string'
        }
    }
    return schema


def default_expire():
    result = timezone.now() + timezone.timedelta(hours=24)

    return result


class Channel(CoreModel):
    # region Fields:...

    id = models.IntegerField(
        verbose_name='ID',
        help_text='не используется',
        primary_key=False,
        default=0,
        blank=True,
        db_column='id',
    )
    name = models.CharField(
        verbose_name='Наименование',
        help_text='Название канала',
        blank=False,
        max_length=200
    )
    code = models.SlugField(
        verbose_name='Код',
        help_text='Уникальный код канала. Должен однозначно идентифицировать'
                  ' канал',
        primary_key=True,
        unique=True,
        blank=False,
    )
    sender = models.CharField(
        verbose_name='Отправитель',
        help_text='Отправитель (вендор) из списка',
        blank=False,
        max_length=200,
        default='',
        choices=Senders.choices,
    )
    config = JSONField(
        verbose_name='Параметры',
        help_text='Структура, описывающая параметры канала. Подключение'
                  ' должно быть описано параметром url в формате'
                  ' <схема>:[//[<логин>[:<пароль>]@]<хост>[:<порт>]]'
                  '[/<URL‐путь>]',
        blank=True,
        default=dict,
        schema=channel_config_schema,
    )
    # endregion

    list_filter = CoreModel.list_filter + ('name', 'sender',)
    search_fields = CoreModel.list_filter + ('name',)

    class Meta:
        db_table = 'channels'
        verbose_name = 'Канал'
        verbose_name_plural = 'Каналы'

    def __str__(self):
        return self.name


class Message(CoreModel):
    # region Fields:...
    eventId = models.CharField(
        verbose_name='Идентификатор события',
        help_text='Уникальный строковый идентификатор, служит для избежания'
                  ' повторных отправок',
        max_length=200,
        default=uuid.uuid4,
    )
    uuid = models.UUIDField(
        verbose_name='Код сообщения',
        help_text='Уникальный строковый идентификатор сообщения в'
                  ' формате UUID',
        blank=True,
        default=uuid.uuid4,
    )
    expire = models.DateTimeField(
        verbose_name='Истекает',
        help_text='Дата и время, до которого сообщение актуально. После'
                  ' этой даты сообщение будет удалено автоматически',
        blank=True,
        default=default_expire,
    )
    mustBeSend = models.DateTimeField(
        verbose_name='Дата отправки',
        help_text='Дата и время, после которого сообщение будет отправлено',
        default=timezone.now,
    )
    subject = models.CharField(
        verbose_name='Тема',
        help_text='Тема сообщения. Используется в некоторых типах уведомлений',
        blank=True,
        max_length=200,
        default='',
    )
    recipientId = models.CharField(
        verbose_name='Код получателя',
        help_text='Идентификатор получателя сообщения из локальной базы'
                  ' пользователей',
        blank=False,
        max_length=200,
        default='',
    )
    content = models.TextField(
        verbose_name='Содержание',
        help_text='Содержание сообщения',
        null=True,
        blank=True,
        default='',
    )
    shortContent = models.CharField(
        verbose_name='Сокращенное содержание',
        help_text='Короткое содержание. Может быть использовано, например, в'
                  ' sms или для других каналах, которые не приемлют длинные'
                  ' сообщения',
        max_length=200,
        null=True,
        blank=True,
        default='',
    )
    htmlContent = models.TextField(
        verbose_name='Содержание html',
        help_text='Содержание, которое может быть использовано, например, в'
                  ' email рассылках или других, поддерживающих html разметку',
        null=True,
        blank=True,
        default='',
    )
    status = models.IntegerField(
        verbose_name='Статус',
        help_text='Текущий статус сообщения. Это максимальный статус от'
                  ' всех отправок',
        blank=False,
        choices=MessageStatuses.choices,
        default=0,
    )
    type = models.IntegerField(
        verbose_name='Тип сообщения',
        help_text='Тип сообщения в соответствии с принятой классификацией.'
                  ' Необходим в случае отсутствия сценария.',
        blank=True,
        null=True,
        choices=MessageTypes.choices,
        default=0,
    )
    channels = JSONField(
        verbose_name='Каналы',
        help_text='Список каналов для отправки уведомлений в соответствии с'
                  ' указанным сценарием. Заполняется автоматически',
        blank=True,
        default=list,
        schema=message_channels_schema,
    )
    tags = JSONField(
        verbose_name='Теги',
        help_text='Теги для дополнительной агрегации сообщений',
        blank=True,
        default=list,
        schema=array_of_string_schema,
    )
    metadata = models.JSONField(
        verbose_name='Дополнительные данные',
        help_text='Метаданные, которые могут использоваться для формирования'
                  ' дополнительных сведений отправки. Например, тут может'
                  ' находится дополнительное поле, которое может быть'
                  ' использовано для указания электронной почты или пр.',
        blank=True,
        default=dict
    )
    scenario = models.ForeignKey(
        'Scenario',
        verbose_name='Сценарий',
        help_text='Сценарий для формирования отправок по сообщению.'
                  ' Может быть опущен, если указан вид сообщения',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        to_field='uuid',
    )
    # endregion

    list_filter = CoreModel.list_filter + (
        'type', 'mustBeSend', 'expire', 'status',)
    search_fields = CoreModel.list_filter + (
        'type', 'subject', 'recipientId', 'status', 'uuid', 'eventId',)

    class Meta:
        db_table = 'messages'
        verbose_name = 'Сообщение'
        verbose_name_plural = 'Сообщения'
        indexes = [models.Index(fields=['recipientId'])]

    def __str__(self):
        str_date = self.createdAt.strftime('%d.%m.%Y %H:%M:%S')

        return f'Сообщение №{self.id} от {str_date}'


class Sending(CoreModel):
    # region Fields:...

    uuid = models.CharField(
        verbose_name='Код сообщения',
        help_text='Уникальный строковый идентификатор сообщения в'
                  ' произвольном формате',
        blank=True,
        max_length=200,
        default='',
    )
    expire = models.DateTimeField(
        verbose_name='Истекает',
        help_text='Дата и время, до которого отправка актуальна. После'
                  ' этой даты отправка будет удалена автоматически',
        blank=True,
        default=default_expire,
    )
    mustBeSend = models.DateTimeField(
        verbose_name='Дата отправки',
        help_text='Дата и время, после которого отправка будет отправлена',
        default=timezone.now,
    )
    subject = models.CharField(
        verbose_name='Тема',
        help_text='Тема отправки. Используется в некоторых типах уведомлений',
        blank=True,
        max_length=200,
        default='',
    )
    content = models.TextField(
        verbose_name='Содержание',
        help_text='Содержание отправки. Может быть заполнено из'
                  ' соответствующего реквизита сообщения, в зависимости от'
                  ' типа отправителя (канала)',
        blank=False,
    )
    destination = models.CharField(
        verbose_name='Назначение',
        help_text='Назначение отправки. Например, для sms - номер телефона,'
                  ' email рассылки - электронная почта и т.д.',
        blank=True,
        max_length=200,
        default=''
    )
    channel = models.ForeignKey(
        'Channel',
        verbose_name='Канал',
        help_text='Канал отправки',
        on_delete=models.CASCADE,
        blank=False,
    )
    status = models.IntegerField(
        verbose_name='Статус',
        help_text='Текущий статус отправки',
        blank=False,
        choices=MessageStatuses.choices,
        default=0,
    )
    message = models.ForeignKey(
        'notifications.Message',
        verbose_name='Сообщение',
        help_text='Родительское сообщение',
        blank=True,
        null=True,
        related_name='sendings',
        on_delete=models.SET_NULL
    )
    # endregion

    list_filter = CoreModel.list_filter + (
        'mustBeSend', 'expire', 'channel', 'status', 'message')
    search_fields = CoreModel.list_filter + (
        'subject', 'uuid', 'status', 'destination',)

    class Meta:
        db_table = 'sendings'
        verbose_name = 'Отправка'
        verbose_name_plural = 'Отправки'

    def __str__(self):
        str_date = self.createdAt.strftime('%d.%m.%Y %H:%M:%S')

        return f'Отправка №{self.id} от {str_date}'


class Scenario(CoreModel):
    # region Fields:...
    uuid = models.UUIDField(
        verbose_name='Идентификатор',
        help_text='Уникальный строковый идентификатор сценария в формате UUID',
        blank=True,
        null=True,
        unique=True,
        default=uuid.uuid4,
    )
    title = models.CharField(
        verbose_name='Наименование',
        help_text='Название сценария',
        max_length=150,
        null=False,
        blank=False,
    )
    description = models.TextField(
        verbose_name='Описание',
        help_text='Описание сценария',
        default='',
        null=True,
        blank=True,
    )
    messageType = models.IntegerField(
        verbose_name='Тип сообщений',
        help_text='Тип сообщений, которые призван обслуживать сценарий',
        unique=False,
        blank=True,
        null=True,
        choices=MessageTypes.choices,
        default=0,
    )
    channelsFirstOf = JSONField(
        verbose_name='Первый из',
        help_text='Список каналов и их настройки для сценария. Из данного'
                  ' списка будет выбран первый канал, который успешно прошел'
                  ' проверку по условиям полей',
        null=True,
        blank=True,
        default=list,
        schema=scenario_config_schema,
    )
    channelsEveryOf = JSONField(
        verbose_name='Каждый из',
        help_text='Список каналов и их настройки для сценария. Из данного'
                  ' списка будет выбран каждый канал, который успешно прошел'
                  ' проверку по условиям полей',
        null=True,
        blank=True,
        default=list,
        schema=scenario_config_schema,
    )
    byDefault = models.BooleanField(
        verbose_name='По умолчанию',
        help_text='Данный признак призван определять сценарий по умолчанию для'
                  ' указанного типа сообщений. Данным признаком единовременно'
                  ' может быть помечен только один сценарий',
        default=False
    )
    # endregion

    list_filter = CoreModel.list_filter + ('messageType', 'byDefault',)
    search_fields = CoreModel.list_filter + ('title', 'firstOf', 'everyOf',)
    readonly_fields = CoreModel.readonly_fields + ('title',)

    class Meta:
        db_table = 'scenarios'
        verbose_name = 'Сценарий'
        verbose_name_plural = 'Сценарии'

    def __str__(self):
        return f'{self.title}'

    def save(self, *args, **kwargs):
        if self.byDefault:
            scenarios = Scenario.objects.filter(
                messageType=self.messageType,
                byDefault=True)
            for scenario in scenarios:
                if self != scenario:
                    scenario.byDefault = False
                    scenario.save()

        first_of = [channel['channel'] for channel in self.channelsFirstOf
                    if channel['isActive']]
        first_of = '/'.join(first_of)
        every_of = [channel['channel'] for channel in self.channelsEveryOf
                    if channel['isActive']]
        every_of = ', '.join(every_of)
        self.title = \
            f'{self.get_messageType_display()}: ({first_of}, {every_of})'
        super().save(*args, **kwargs)
