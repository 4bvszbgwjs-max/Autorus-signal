from django_filters import rest_framework as filters

from common.filters import CoreFilter
from notifications.models import Channel, Message, Sending, Scenario


class ChannelFilter(CoreFilter):
    class Meta:
        model = Channel
        fields = Channel.search_fields


class MessageFilter(CoreFilter):
    class Meta:
        model = Message
        fields = Message.search_fields


class SendingFilter(CoreFilter):
    expire = filters.IsoDateTimeFromToRangeFilter()
    mustBeSend = filters.IsoDateTimeFromToRangeFilter()

    class Meta:
        model = Sending
        fields = Sending.search_fields + ('mustBeSend', 'expire')


class ScenarioFilter(CoreFilter):
    class Meta:
        model = Scenario
        fields = Scenario.list_filter
