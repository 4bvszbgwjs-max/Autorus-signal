from celery.exceptions import Retry
from db_mutex import DBMutexError, DBMutexTimeoutError
from db_mutex.db_mutex import db_mutex

from config.celery import app, logger
from notifications.services import MessageService, SendingService, \
    ChannelService


@app.on_after_finalize.connect
def setup_periodic_tasks(sender, **kwargs):
    sender.add_periodic_task(
        1.01,
        periodic_expiring_messages.s(),
        name='Regular handling of expired messages'
    )
    sender.add_periodic_task(
        1.03,
        periodic_creating_sendings.s(),
        name='Creating new sendings for messages'
    )
    sender.add_periodic_task(
        1.04,
        periodic_status_update.s(),
        name='Regular status updating'
    )
    sender.add_periodic_task(
        1.05,
        periodic_put_messages_to_queue.s(),
        name='Regular sending messages'
    )
    sender.add_periodic_task(
        61.3,
        periodic_messages_delete_expire.s(),
        name='Cleaning of system garbage'
    )


# region Periodic tasks


@app.task
def periodic_put_messages_to_queue():
    try:
        with db_mutex('put_messages_to_queue'):
            logger.debug('START put messages to queue...')
            # TODO: Сделать более абстрактно
            map_channel_tasks = {
                ChannelService.senders.EMAIL_BUILTIN: task_send_mail,
                ChannelService.senders.SMS_IDGTL: task_send_sms,
                ChannelService.senders.PUSH_FIREBASE: task_send_push,
                ChannelService.senders.TELEGRAM: task_send_telegram,
                ChannelService.senders.NOTICES: task_send_notices,
                ChannelService.senders.EMAIL_RETAILROCKET: task_send_mail,
            }
            SendingService().put_new_to_queue(map_channel_tasks)
            logger.debug('END put messages to queue...')

    except DBMutexError:
        logger.debug('Could not obtain lock')

    except DBMutexTimeoutError:
        logger.debug('Task completed but the lock timed out')


@app.task
def periodic_expiring_messages():
    try:
        with db_mutex('expiring_messages'):
            logger.debug('START handling of expired messages...')
            MessageService().set_expiration()
            SendingService().set_expiration()
            logger.debug('END handling of expired messages...')

    except DBMutexError:
        logger.debug('Could not obtain lock')

    except DBMutexTimeoutError:
        logger.debug('Task completed but the lock timed out')


@app.task
def periodic_creating_sendings():
    try:
        with db_mutex('periodic_creating_sendings'):
            logger.debug('START creating sendings...')
            MessageService().create_sendings_from_new_messages()
            logger.debug('END creating sendings...')

    except DBMutexError:
        logger.debug('Could not obtain lock')

    except DBMutexTimeoutError:
        logger.debug('Task completed but the lock timed out')


@app.task
def periodic_status_update():
    try:
        with db_mutex('periodic_status_update'):
            logger.debug('START put messages to queue...')
            MessageService().periodic_status_update()
            logger.debug('END put messages to queue...')

    except DBMutexError:
        logger.debug('Could not obtain lock')

    except DBMutexTimeoutError:
        logger.debug('Task completed but the lock timed out')


@app.task
def periodic_messages_delete_expire():
    try:
        with db_mutex('periodic_system_prune'):
            logger.debug('START system prune...')
            MessageService().delete_expire()
            logger.debug('END system prune...')

    except DBMutexError:
        logger.debug('Could not obtain lock')

    except DBMutexTimeoutError:
        logger.debug('Task completed but the lock timed out')


# endregion

# region Sending messages

@app.task(
    bind=True,
    default_retry_delay=10,
    max_retries=10,
    rate_limit=50,
    acks_late=True,
)
def task_send_mail(self, **kwargs):
    message_id = kwargs.get('id')

    try:
        sent = SendingService().send_by_id(message_id)

        if not sent:
            raise Retry()

    except Exception as exc:
        logger.exception(f'Sending mail id={message_id} failed')
        self.retry(exc=exc)


@app.task(
    bind=True,
    default_retry_delay=3,
    max_retries=3,
    rate_limit=20,
    acks_late=True,
)
def task_send_sms(self, **kwargs):
    message_id = kwargs.get('id')

    try:
        sent = SendingService().send_by_id(message_id)

        if not sent:
            raise Retry()

    except Exception as exc:
        logger.exception(f'Sending sms id={message_id} failed')
        self.retry(exc=exc)


@app.task(
    bind=True,
    default_retry_delay=10,
    max_retries=10,
    rate_limit=50,
    acks_late=True,
)
def task_send_push(self, **kwargs):
    message_id = kwargs.get('id')

    try:
        sent = SendingService().send_by_id(message_id)

        if not sent:
            raise Retry()

    except Exception as exc:
        logger.exception(f'Sending push notify id={message_id} failed')
        self.retry(exc=exc)


@app.task(
    bind=True,
    default_retry_delay=10,
    max_retries=3,
    rate_limit=25,
    acks_late=True,
)
def task_send_telegram(self, **kwargs):
    message_id = kwargs.get('id')

    try:
        sent = SendingService().send_by_id(message_id)

        if not sent:
            raise Retry()

    except Exception as exc:
        logger.exception(f'Sending telegram message id={message_id} failed')
        self.retry(exc=exc)


@app.task(
    bind=True,
    default_retry_delay=10,
    max_retries=3,
    rate_limit=25,
    acks_late=True,
)
def task_send_notices(self, **kwargs):
    messages = kwargs.get('messages')
    message_ids = []
    for message in messages:
        message_ids.append(message.get('id'))
    try:
        sent = SendingService().send_by_ids(message_ids)

        if not sent:
            raise Retry()

    except Exception as exc:
        logger.exception(f'Sending messages {",".join(map(str, message_ids))} to Notices failed')
        self.retry(exc=exc)

# endregion
