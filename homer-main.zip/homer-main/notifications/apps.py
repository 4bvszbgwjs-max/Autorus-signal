import logging
import sys

from django.apps import AppConfig

logger = logging.getLogger(__name__)


class MessageServiceConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'notifications'
    verbose_name = 'Уведомления'

    def ready(self):
        super().ready()
        arg_string = ' '.join(sys.argv)

        if 'gunicorn' in arg_string:
            logger.info(f'Started Web server {arg_string}')

        if 'celery' in arg_string and 'main' in arg_string:
            from db_mutex.models import DBMutex
            DBMutex.objects.all().delete()
            logger.info(f'Started Celery main worker and Scheduler '
                        f'{arg_string}')

        if 'startconsume' in arg_string:
            logger.info(f'Started rabbitmq consuming worker {arg_string}')

        if 'celery' in arg_string and 'send' in arg_string:
            logger.info(f'Started Celery sending worker {arg_string}')

