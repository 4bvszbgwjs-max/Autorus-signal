from django.test import TestCase
from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase

from notifications.models import Channel, Message, Sending, Scenario
from notifications.services import SendingService, MessageService, \
    ChannelService, ScenarioService
from recipients.models import Recipient

channel = {
    'code': 'email1',
    'createdAt': '2022-12-16T11:03:46.256Z',
    'updatedAt': '2022-12-16T11:03:46.256Z',
    'isDeleted': False,
    'id': 0,
    'name': 'no-reply@autorus.ru',
    'sender': 'builtinEmail',
    'config': {
        'ssl': False,
        'port': 25,
        'user': 'no-reply@voshod.local',
        'email': 'no-reply@autorus.ru',
        'server': '192.168.10.248',
        'password': 'sd344@#'
    }
}
channel_update = {
    'code': 'email1',
    'createdAt': '2022-12-16T11:03:46.256Z',
    'updatedAt': '2022-12-16T11:03:46.256Z',
    'isDeleted': True,
    'id': 0,
    'name': 'no-reply@autorus.ru',
    'sender': 'builtinEmail',
    'config': {
        'ssl': False,
        'port': 25,
        'user': 'no-reply@voshod.local',
        'email': 'no-reply@autorus.ru',
        'server': '192.168.10.248',
        'password': 'sd344@#'
    }
}
message = {
    'createdAt': '2022-12-19T08:04:17.924Z',
    'updatedAt': '2022-12-19T08:04:17.924Z',
    'isDeleted': False,
    'uuid': '0d0fee55-e0de-4d46-b91e-da82cbab34fc',
    'expire': '2022-12-20T08:04:17.911Z',
    'mustBeSend': '2022-12-19T08:04:17.911Z',
    'subject': 'Autorus PUSH from postman',
    'recipientId': '+79124994865',
    'content': '200a0126-827c-4cd9-ac90-2e98b48b0578',
    'shortContent': '',
    'htmlContent': '',
    'status': 0,
    'type': 0,
    'channels': ['push'],
    'tags': [],
    'metadata': {},
    'scenario_id': 'dd13dfd5-9e5e-4a1d-9aa7-56a7dd9520b7',
    'eventId': '5f5c1db4-c8a1-11ed-afa1-0242ac120002'
}
message_update = {
    'createdAt': '2022-12-19T08:04:17.924Z',
    'updatedAt': '2022-12-19T08:04:17.924Z',
    'isDeleted': False,
    'uuid': '0d0fee55-e0de-4d46-b91e-da82cbab34fc',
    'expire': '2022-12-20T08:04:17.911Z',
    'mustBeSend': '2022-12-19T08:04:17.911Z',
    'subject': 'Autorus PUSH from postman',
    'recipientId': '+79124994865',
    'content': '200a0126-827c-4cd9-ac90-2e98b48b0578',
    'shortContent': '',
    'htmlContent': '',
    'status': 3,
    'type': 0,
    'channels': ['push'],
    'tags': [],
    'metadata': {},
    'scenario_id': 'dd13dfd5-9e5e-4a1d-9aa7-56a7dd9520b7',
    'eventId': '5f5c1db4-c8a1-11ed-afa1-0242ac120002'
}
sending = {
    'createdAt': '2022-12-19T08:04:19.387Z',
    'updatedAt': '2022-12-19T08:04:19.387Z',
    'isDeleted': False,
    'uuid': '',
    'expire': '2022-12-20T08:04:17.911Z',
    'mustBeSend': '2022-12-19T08:04:17.911Z',
    'subject': 'Autorus PUSH from postman',
    'destination': '',
    'content': '200a0126-827c-4cd9-ac90-2e98b48b0578',
    'channel_id': 'push',
    'status': 0,
    'message_id': 35
}
sending_update = {
    'createdAt': '2022-12-19T08:04:19.387Z',
    'updatedAt': '2022-12-19T08:04:19.387Z',
    'isDeleted': False,
    'uuid': '',
    'expire': '2022-12-20T08:04:17.911Z',
    'mustBeSend': '2022-12-19T08:04:17.911Z',
    'subject': 'Autorus PUSH from postman',
    'destination': '',
    'content': '200a0126-827c-4cd9-ac90-2e98b48b0578',
    'channel_id': 'push',
    'status': 1,
    'message_id': 35
}
scenario = {
    'createdAt': '2023-03-04T16:21:32.145Z',
    'updatedAt': '2023-03-04T16:21:32.145Z',
    'isDeleted': False,
    'title': 'Акции: (sms, notices)',
    'description': '',
    'messageType': 2,
    'channelsFirstOf': [
        {
            'channel': 'sms',
            'isActive': True,
            'destinationField': 'phone',
            'fieldsConditions':
                {
                    'notNone': ['phone'],
                    'equalTrue': ['isPhoneConfirmed'],
                    'equalFalse': []
                },
            'destinationFieldPath': ''
        }
    ],
    'channelsEveryOf': [
        {
            'channel': 'notices',
            'isActive': True,
            'destinationField': '',
            'fieldsConditions': {
                'notNone': [],
                'equalTrue': [],
                'equalFalse': []
            },
            'destinationFieldPath': ''
        }
    ],
    'uuid': 'dd13dfd5-9e5e-4a1d-9aa7-56a7dd952010',
    'byDefault': False
}
scenario_update = {
    'description': 'New description',
}


class ChannelTest(TestCase):
    fixtures = ['initial_data.json']

    def setUp(self):
        self.model = Channel
        self.data_for_create = channel
        self.data_for_update = channel_update
        self.fields = [field.name for field in self.model._meta.get_fields()
                       if not field.auto_created and not field.is_relation
                       and field.name not in self.model.readonly_fields]
        self.item = self.model.objects.create(**self.data_for_create)
        self.item.save()

    def tearDown(self):
        self.item.delete()

    def test_read_model(self):
        [self.assertEqual(getattr(self.item, field),
                          self.data_for_create[field]) for field in
         self.fields]

    def test_update_model(self):
        [setattr(self.item, field, self.data_for_update[field])
         for field in self.fields]
        self.item.save()
        [self.assertEqual(getattr(self.item, field),
                          self.data_for_update[field]) for field in
         self.fields]


class MessageTest(TestCase):
    fixtures = ['initial_data.json']

    def setUp(self):
        self.model = Message
        self.data_for_create = message
        self.data_for_update = message_update
        self.fields = [field.name for field in self.model._meta.get_fields()
                       if not field.auto_created and not field.is_relation
                       and field.name not in self.model.readonly_fields]
        self.item = self.model.objects.create(**self.data_for_create)
        self.item.save()

    def tearDown(self):
        self.item.delete()

    def test_read_model(self):
        [self.assertEqual(getattr(self.item, field),
                          self.data_for_create[field]) for field in
         self.fields]

    def test_update_model(self):
        [setattr(self.item, field, self.data_for_update[field])
         for field in self.fields]
        self.item.save()
        [self.assertEqual(getattr(self.item, field),
                          self.data_for_update[field]) for field in
         self.fields]


class SendingTest(TestCase):
    fixtures = ['initial_data.json']

    def setUp(self):
        self.model = Sending
        self.data_for_create = sending
        self.data_for_update = sending_update
        self.fields = [field.name for field in self.model._meta.get_fields()
                       if not field.auto_created and not field.is_relation
                       and field.name not in self.model.readonly_fields]
        self.item = self.model.objects.create(**self.data_for_create)
        self.item.save()

    def tearDown(self):
        self.item.delete()

    def test_read_model(self):
        [self.assertEqual(getattr(self.item, field),
                          self.data_for_create[field]) for field in
         self.fields]

    def test_update_model(self):
        [setattr(self.item, field, self.data_for_update[field])
         for field in self.fields]
        self.item.save()
        [self.assertEqual(getattr(self.item, field),
                          self.data_for_update[field]) for field in
         self.fields]


class ScenarioTest(TestCase):
    fixtures = ['initial_data.json']

    def setUp(self):
        self.model = Scenario
        self.data_for_create = scenario
        self.data_for_update = scenario_update
        self.fields = [field.name for field in self.model._meta.get_fields()
                       if not field.auto_created and not field.is_relation
                       and field.name not in self.model.readonly_fields]
        self.item = self.model.objects.create(**self.data_for_create)
        self.item.save()

    def tearDown(self):
        self.item.delete()

    def test_read_model(self):
        [self.assertEqual(getattr(self.item, field),
                          self.data_for_create[field]) for field in
         self.fields]

    def test_update_model(self):
        [setattr(self.item, field, self.data_for_update[field])
         for field in self.fields if field in self.data_for_update.keys()]
        self.item.save()
        [self.assertEqual(getattr(self.item, field),
                          self.data_for_update[field]) for field in
         self.fields if field in self.data_for_update.keys()]


class PrometheusMetricsTest(APITestCase):
    def test_api_message_create(self):
        response = self.client.get(reverse('metrics'))
        self.assertEqual(response.status_code, status.HTTP_200_OK)


class APITestMessage(APITestCase):
    fixtures = ['initial_data.json']

    def test_api_message_create(self):
        response = self.client.post(reverse('message-list'), message)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_api_message_update(self):
        response = self.client.put(reverse('message-detail', args=[35]),
                                   data=message_update)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_api_message_partial_update(self):
        response = self.client.patch(reverse('message-detail', args=[35]),
                                     data={'status': 4})
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_api_message_read(self):
        response = self.client.get(reverse('message-detail', args=[35]))
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_api_message_list(self):
        response = self.client.get(reverse('message-list'))
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_api_message_delete(self):
        response = self.client.delete(reverse('message-detail', args=[35]))
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)

    def test_api_message_bulk_remove(self):
        data = [{'uuid': 'd2e67140-052b-45df-ae9b-7480241b8e6b'},
                {'uuid': '31296ec4-9663-43f7-a3e2-29a3fefddb8d'}]
        response = self.client.patch(reverse('message-bulk-remove'), data=data)
        self.assertEqual(response.status_code, status.HTTP_200_OK)


class APITestSending(APITestCase):
    fixtures = ['initial_data.json']

    def setUp(self):
        self.model = Sending
        self.data_for_create = sending
        self.data_for_update = sending_update

    def test_api_sending_create(self):
        data = {**self.data_for_create,
                **{'channel': self.data_for_create['channel_id']}}
        response = self.client.post(reverse('sending-list'), data)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_api_sending_update(self):
        data = {**self.data_for_update,
                **{'channel': self.data_for_update['channel_id']}}
        response = self.client.put(reverse('sending-detail', args=[44]),
                                   data=data)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_api_sending_partial_update(self):
        response = self.client.patch(reverse('sending-detail', args=[44]),
                                     data={'status': 4})
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_api_sending_read(self):
        response = self.client.get(reverse('sending-detail', args=[44]))
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_api_sending_list(self):
        response = self.client.get(reverse('sending-list'))
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_api_sending_delete(self):
        response = self.client.delete(reverse('sending-detail', args=[44]))
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)

    def test_api_sending_bulk_remove(self):
        data = [{'id': 50}, {'id': 51}]
        response = self.client.patch(reverse('sending-bulk-remove'), data=data)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_api_idgtl_status(self):
        data = [{'messageUuid': '0:1671445858053103%b08daca1b08daca1',
                 'status': 'delivered'}]
        response = self.client.patch(reverse('sending-status'), data=data)
        self.assertEqual(response.status_code, status.HTTP_200_OK)


class APITestChannel(APITestCase):
    fixtures = ['initial_data.json']

    def test_api_1_channel_create(self):
        response = self.client.post(reverse('channel-list'), channel)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_api_2_channel_update(self):
        response = self.client.put(reverse('channel-detail', args=['email']),
                                   data=channel_update)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_api_3_channel_partial_update(self):
        response = self.client.patch(reverse('channel-detail', args=['email']),
                                     data={'isDeleted': True})
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_api_4_channel_read(self):
        response = self.client.get(reverse('channel-detail', args=['email']))
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_api_5_channel_list(self):
        response = self.client.get(reverse('channel-list'))
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_api_6_channel_delete(self):
        response = self.client.delete(
            reverse('channel-detail', args=['email']))
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)


class APITestScenario(APITestCase):
    fixtures = ['initial_data.json']

    def test_api_1_scenario_create(self):
        response = self.client.post(reverse('scenario-list'), scenario)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_api_2_scenario_update(self):
        response = self.client.put(reverse('scenario-detail', args=[4]),
                                   data=scenario)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_api_3_scenario_partial_update(self):
        response = self.client.patch(reverse('scenario-detail', args=[4]),
                                     data={'isDeleted': True})
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_api_4_scenario_read(self):
        response = self.client.get(reverse('scenario-detail', args=[4]))
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_api_5_scenario_list(self):
        response = self.client.get(reverse('scenario-list'))
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_api_6_scenario_delete(self):
        response = self.client.delete(
            reverse('scenario-detail', args=[4]))
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)


class SendingServiceTest(TestCase):
    fixtures = ['initial_data.json']

    class SenderHandlersMock:
        class Mock:
            @classmethod
            def delay(cls, **kwargs):
                ...

        map_channel_tasks = {
            ChannelService.senders.EMAIL_BUILTIN: Mock,
            ChannelService.senders.SMS_IDGTL: Mock,
            ChannelService.senders.PUSH_FIREBASE: Mock,
            ChannelService.senders.TELEGRAM: Mock,
            ChannelService.senders.NOTICES: Mock,
            ChannelService.senders.EMAIL_RETAILROCKET: Mock,
        }

        def __getitem__(self, key):
            return self.map_channel_tasks.get(key)

    def setUp(self):
        self.service = SendingService

    def test_set_expiration(self):
        service = self.service()
        result = service.set_expiration()
        self.assertEqual(result, True)

    def test_put_new_to_queue(self):
        service = self.service()
        result = service.put_new_to_queue(
            SendingServiceTest.SenderHandlersMock.map_channel_tasks)
        self.assertEqual(result, True)


class MessageServiceTest(TestCase):
    fixtures = ['initial_data.json']

    def setUp(self):
        self.service = MessageService

    def test_create_sendings_from_new_messages(self):
        service = self.service()
        result = service.create_sendings_from_new_messages()
        self.assertEqual(result, True)

    def test_periodic_status_update(self):
        service = self.service()
        result = service.periodic_status_update()
        self.assertEqual(result, True)

    def test_delete_expire(self):
        service = self.service()
        result = service.delete_expire()
        self.assertEqual(result, True)

    def test_consume(self):
        service = self.service()
        payload = '{"recipientId": "+79124994865", "subject": ' \
                  '"Подтверждение", "content": "Код для подтверждения номера ' \
                  'телефона: 0000"}'
        result = service.consume(payload)
        self.assertEqual(result, True)


class ScenarioServiceTest(TestCase):
    fixtures = ['initial_data.json']

    def setUp(self):
        self.service = ScenarioService
        self.message = Message.objects.get(id=35)
        self.scenario = Scenario.objects.get(id=4)
        self.recipient = Recipient.objects.get(id=1)

    def test_get_message_scenario(self):
        service = self.service()
        result = service.get_message_scenario(self.message)
        self.assertEqual(result, self.scenario)

    def test_get_scenario_by_default(self):
        service = self.service()
        result = service.get_scenario_by_default(self.scenario.messageType)
        self.assertEqual(result, self.scenario)

    def test_get_available_channels(self):
        service = self.service()
        result = service.get_available_channels(
            self.scenario, self.recipient)
        self.assertEqual(set(result), {'notices', 'sms'})


class ChannelServiceTest(TestCase):
    fixtures = ['initial_data.json']

    def setUp(self):
        self.service = ChannelService
        self.channel = Channel.objects.get(pk='notices')

    def test_get_cached(self):
        result = self.service.get_cached('notices')
        self.assertEqual(self.channel, result)
