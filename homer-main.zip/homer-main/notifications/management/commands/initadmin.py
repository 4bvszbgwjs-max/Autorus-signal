import logging
import os

from django.contrib.auth.models import User
from django.core.management.base import BaseCommand

DJANGO_SUPERUSER_USERNAME = os.environ.get('DJANGO_SUPERUSER_USERNAME')
DJANGO_SUPERUSER_PASSWORD = os.environ.get('DJANGO_SUPERUSER_PASSWORD')
DJANGO_SUPERUSER_EMAIL = os.environ.get('DJANGO_SUPERUSER_EMAIL')

logger = logging.getLogger(__name__)


class Command(BaseCommand):
    help = 'Creates a superuser if it does not exist'

    def handle(self, *args, **options):
        if User.objects.count() == 0 \
                and DJANGO_SUPERUSER_USERNAME \
                and DJANGO_SUPERUSER_PASSWORD \
                and DJANGO_SUPERUSER_EMAIL:
            User.objects.create_user(
                username=DJANGO_SUPERUSER_USERNAME,
                password=DJANGO_SUPERUSER_PASSWORD,
                email=DJANGO_SUPERUSER_EMAIL,
                is_active=True,
                is_superuser=True,
                is_staff=True,
            )
            logging.info(f'A superuser has been created '
                         f'{DJANGO_SUPERUSER_USERNAME} '
                         f'<{DJANGO_SUPERUSER_EMAIL}>')
