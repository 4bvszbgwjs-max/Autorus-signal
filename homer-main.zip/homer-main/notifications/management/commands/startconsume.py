from django.core.management.base import BaseCommand
from common.consumers import consumers_manager, logger


class Command(BaseCommand):
    help = 'Starts consuming of queues from outer rabbitmq'

    def handle(self, *args, **options):
        consumers_manager.start_all()
        logger.info('All consumers have been started')
