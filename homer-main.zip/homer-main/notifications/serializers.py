from rest_framework import serializers

from common import MessageStatuses
from common.models import CoreModel
from notifications.models import Message, Channel, Sending, Scenario


class ChannelSerializer(serializers.ModelSerializer):
    class Meta:
        model = Channel
        read_only_fields = CoreModel.readonly_fields
        fields = '__all__'
        extra_kwargs = {'id': {'read_only': False}}


class ScenarioSerializer(serializers.ModelSerializer):
    class Meta:
        model = Scenario
        read_only_fields = CoreModel.readonly_fields
        fields = '__all__'
        extra_kwargs = {'id': {'read_only': False}}


class MessageSerializer(serializers.ModelSerializer):
    eventId = serializers.CharField(required=False, allow_null=True,
                                    allow_blank=True)
    scenario_id = serializers.UUIDField(required=False)

    class Meta:
        model = Message
        read_only_fields = CoreModel.readonly_fields
        exclude = ('scenario',)
        extra_kwargs = {'id': {'read_only': False}}


class SendingSerializer(serializers.ModelSerializer):
    class Meta:
        model = Sending
        read_only_fields = CoreModel.readonly_fields
        fields = '__all__'
        extra_kwargs = {'id': {'read_only': False}}


class SendingStatusSerializer(serializers.ModelSerializer):
    _status_map: dict[MessageStatuses] = {
        'delivered': MessageStatuses.DELIVERED,
        'undelivered': MessageStatuses.UNDELIVERED,
        'unsent': MessageStatuses.UNSENT,
        'sent': MessageStatuses.SENT,
        'sending': MessageStatuses.SENT,
    }

    class Meta:
        read_only_fields = CoreModel.readonly_fields
        model = Sending
        fields = ('status', 'uuid',)

    def to_internal_value(self, data):
        data_status = data.get('status')
        message_uuid = data.get('messageUuid', None)
        uuid = data.get('uuid', None)
        status = self._status_map.get(data_status)
        result = {
            'status': status or data_status or MessageStatuses.DELIVERED,
            'uuid': uuid or message_uuid
        }

        return result
