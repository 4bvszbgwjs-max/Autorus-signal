from functools import lru_cache


def get_section_data_by_path(data: dict, path: str, separator: str = '.'):
    result = None

    if path and isinstance(data, dict):
        list_path = path.split(separator)
        result = data.copy()

        for section in list_path:
            result = result.get(section, None)

            if result is None:
                return None

    return result


@lru_cache
def format_phone(cls, phone_number: str, frms: str = '+7') -> str:
    numbers = list(filter(str.isdigit, phone_number))[1:]

    if len(numbers) == 9 and numbers[0] != 9:
        numbers.insert(0, 9)

    format_string = frms + '{}{}{}{}{}{}{}{}{}{}'
    result = format_string.format(*numbers)

    return result
