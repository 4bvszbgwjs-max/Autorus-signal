from types import FunctionType

from django.http import HttpResponse
from prometheus_client import CollectorRegistry, REGISTRY, generate_latest, \
    CONTENT_TYPE_LATEST
from prometheus_client.metrics import Gauge

from notifications.services import SendingService, MessageService


class Metric:
    def __init__(self, name: str, documentation: str, label_names: tuple[str],
                 registry: CollectorRegistry, handler: FunctionType):
        self.metric = Gauge(
            name,
            documentation,
            label_names,
            registry=registry
        )
        self.handler = handler

    def evaluate(self):
        metric_data = self.handler()
        [self.metric.labels(*item[0]).set(item[1])
         for item in metric_data]


class Metrics:
    _metrics = []

    def __init__(self, registry):
        self.registry = registry

    def append(self, name: str, documentation: str, label_names, handler):
        metric = Metric(name, documentation, label_names, self.registry,
                        handler)
        self._metrics.append(metric)

    def collect(self):
        for metric in self._metrics:
            metric.evaluate()


metrics = Metrics(REGISTRY)
metrics.append('homer_messages_statistics',
               'Statistics of messages by statuses',
               ('Status',),
               MessageService().get_statistic_by_status)
metrics.append('homer_sendings_statistics_status',
               'Statistics of sendings by statuses and type of channels',
               ('Status',),
               SendingService().get_statistic_by_status)
metrics.append('homer_sendings_statistics_channel',
               'Statistics of sendings by statuses and type of channels',
               ('Channel',),
               SendingService().get_statistic_by_channel)


def export_to_django_view(request):
    metrics_page = generate_latest(metrics.registry)
    metrics.collect()

    return HttpResponse(
        metrics_page, content_type=CONTENT_TYPE_LATEST
    )
