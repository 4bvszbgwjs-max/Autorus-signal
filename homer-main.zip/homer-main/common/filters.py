from django_filters import rest_framework as filters


class CoreFilter(filters.FilterSet):
    updatedAt = filters.IsoDateTimeFromToRangeFilter()
    createdAt = filters.IsoDateTimeFromToRangeFilter()
    isDeleted = filters.BooleanFilter
