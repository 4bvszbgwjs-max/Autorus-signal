from django.db import models


class Senders(models.TextChoices):
    UNKNOWN = '', 'Неизвестно'
    NOTICES = 'notices', 'Сервис Notices'
    EMAIL_BUILTIN = 'builtinEmail', 'EMAIL: Встроенный отправщик'
    SMS_IDGTL = 'smsIdgtl', 'SMS: i-dgtl.ru'
    EMAIL_RETAILROCKET = 'emailRetailRocket', 'EMAIL: retailrocket.ru'
    PUSH_FIREBASE = 'pushFirebase', 'PUSH: Firebase'
    TELEGRAM = 'telegram', 'Telegram'


class MessageStatuses(models.IntegerChoices):
    NEW = 0, 'Новое'
    READY = 1, 'Готово к отправке'
    QUEUED = 2, 'Отправляется'
    SENT = 3, 'Отправлено'
    UNSENT = 4, 'Не отправлено'
    UNDELIVERED = 5, 'Не доставлено'
    EXPIRED = 6, 'Просрочено'
    DELIVERED = 7, 'Доставлено'
    ARCHIVED = 8, 'Прочитано'


class MessageTypes(models.IntegerChoices):
    SERVICE = 0, 'Сервисное'
    ORDERS = 1, 'Заказы'
    PROMO = 2, 'Акции'


class ContentTypes(models.IntegerChoices):
    TEXT = 0, 'Простой текст'
    HTML = 1, 'HTML'
