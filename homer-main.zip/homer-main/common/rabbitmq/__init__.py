__all__ = ('core', 'Consumer', 'ConsumersManager')

import threading

from common.rabbitmq.core import Consumer


class ConsumersManager:
    consumers = {}
    workers = {}
    broker_url = ''

    def __init__(self, **kwargs):
        self.broker_url = kwargs.get('broker_url')

    def add_consumer(self, name: str, total: int, **kwargs) -> None:
        kwargs['url'] = self.broker_url
        consumers = []

        for index in range(total):
            new_messages_consumer = Consumer(**kwargs)
            consumers.append(new_messages_consumer)

        self.consumers[name] = consumers

    @staticmethod
    def start_consumer(consumer: Consumer) -> threading.Thread:
        worker = threading.Thread(target=consumer.start)
        worker.start()

        return worker

    def start_consumer_by_name(self, name: str) -> list:
        workers = []

        for consumer in self.consumers[name]:
            worker = self.start_consumer(consumer)
            workers.append(worker)

        self.workers[name] = workers

        return workers

    def start_all(self):
        for consumer_name in self.consumers:
            self.start_consumer_by_name(consumer_name)
