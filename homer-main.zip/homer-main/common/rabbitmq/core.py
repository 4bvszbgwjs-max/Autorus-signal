import logging

import pika
from pika.exchange_type import ExchangeType

logger = logging.getLogger(__name__)


class Consumer:

    def __init__(self, **kwargs):
        self.url = kwargs.get('url')
        self.queue = kwargs.get('queue')
        self.exchange = kwargs.get('exchange')
        self.routing_key = kwargs.get('routing_key')
        self.on_message = kwargs.get('on_message')
        self.exchange_type = kwargs.get('exchange_type', ExchangeType.direct)
        self.prefetch_count = kwargs.get('prefetch_count', 10)
        self.parameters = pika.URLParameters(self.url)
        self.connection = pika.BlockingConnection(self.parameters)
        self.channel = self.connection.channel()

    def start(self):
        self.channel.queue_declare(
            queue=self.queue,
            durable=True
        )
        self.channel.exchange_declare(
            exchange=self.exchange,
            exchange_type=self.exchange_type,
            durable=True
        )
        self.channel.queue_bind(
            exchange=self.exchange,
            queue=self.queue,
            routing_key=self.routing_key
        )
        self.channel.basic_qos(prefetch_count=self.prefetch_count)
        self.channel.basic_consume(self.queue, self.on_message_callback)

        try:
            self.channel.start_consuming()
            logger.info(f'Start consuming queue {self.queue}')

        except KeyboardInterrupt:
            self.stop()

        except Exception:
            logger.exception(f'Error consuming queue {self.queue}')
            self.stop()

    def stop(self):
        logger.info(f'Stop consuming queue {self.queue}')
        self.channel.stop_consuming()

    def on_message_callback(self, channel, method, properties, body):
        try:
            success = self.on_message(body.decode('utf-8'))

            if success:
                channel.basic_ack(delivery_tag=method.delivery_tag)

        except Exception:
            logger.exception(f'An error occurred when receive new message '
                              f'from {method.routing_key}')
            channel.basic_reject(delivery_tag=method.delivery_tag,
                                 requeue=False)
