from django.contrib.auth import get_user_model, authenticate
from django.test import TestCase
from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase


class SigninTest(TestCase):

    def setUp(self):
        self.user = get_user_model().objects.create_user(
            username='test',
            password='12test12',
            email='test@example.com',
            is_staff=True,
        )
        self.user.save()

    def tearDown(self):
        self.user.delete()

    def test_correct(self):
        user = authenticate(username='test', password='12test12')
        self.assertTrue((user is not None) and user.is_authenticated)

    def test_wrong_username(self):
        user = authenticate(username='wrong', password='12test12')
        self.assertFalse(user is not None and user.is_authenticated)

    def test_wrong_password(self):
        user = authenticate(username='test', password='wrong')
        self.assertFalse(user is not None and user.is_authenticated)


class APITestPing(APITestCase):

    def test_api_ping(self):
        response = self.client.get(reverse('ping'))
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_api_schema(self):
        response = self.client.get(reverse('openapi'))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
