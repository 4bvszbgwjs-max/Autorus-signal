import logging

from common import rabbitmq
from config.settings import RMQ_BROKER_URL, RMQ_CREATE_MESSAGE_EXCHANGE
from notifications.services import MessageService

logger = logging.getLogger(__name__)
consumers_manager = rabbitmq.ConsumersManager(broker_url=RMQ_BROKER_URL)

if RMQ_CREATE_MESSAGE_EXCHANGE:
    consumers_manager.add_consumer(
        'create_message',
        1,
        queue=RMQ_CREATE_MESSAGE_EXCHANGE,
        exchange=RMQ_CREATE_MESSAGE_EXCHANGE,
        routing_key='',
        prefetch_count=100,
        on_message=MessageService().consume,
    )
