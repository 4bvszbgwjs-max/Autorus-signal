import json
import logging
from abc import ABC

from django.db import models
from django.utils import timezone
from rest_framework import serializers
from rest_framework.exceptions import APIException, ValidationError, \
    ErrorDetail

logger = logging.getLogger(__name__)


class Factory(ABC):
    def __init__(self):
        self._builders = {}

    def register_builder(self, key, builder):
        self._builders[key] = builder

    def create(self, key, **kwargs):
        builder = self._builders.get(key)

        if not builder:
            raise ValueError(key)

        return builder(**kwargs)


class ServiceAPIException(APIException):
    default_code = 'service_class_error'


class ServiceHandlerExceptions:

    def __init__(self, service_method):
        self.service_method = service_method

    def __enter__(self):
        logger.debug(self.service_method)

        return self

    def __exit__(self, exc_type, exc_value, exc_traceback):
        if exc_type:
            logger.exception(self.service_method)

            if exc_type == ValidationError:
                raise exc_value

            error_detail = ErrorDetail(str(exc_type), code=self.service_method)
            detail = {str(exc_value): error_detail}
            service_exception = ServiceAPIException(detail=detail)

            raise service_exception


class ServiceBatchFetch(ABC):
    limit: int = 1000
    filter: dict = {}
    exclude_filter: dict = {}
    values_fields: tuple = ()
    values_list_fields: tuple = ()

    def __init__(self, **kwargs):
        self.model: models.Model = kwargs.get('model')
        self.last_id: int = 0

    def __iter__(self, **kwargs):
        self.last_id = 0
        self.limit: int = kwargs.get('limit', self.limit)
        self.filter: dict = kwargs.get('filter', self.filter)
        self.values_fields: list = kwargs.get('values_fields',
                                              self.values_fields)
        self.values_list_fields: list = kwargs.get('values_list_fields',
                                                   self.values_list_fields)

        return self

    def __next__(self):
        items = self.model.objects.filter(
            id__gt=self.last_id, **self.filter)

        if self.exclude_filter:
            items = items.exclude(**self.exclude_filter)

        items = items.order_by('id')[:self.limit]

        if not items.exists():
            raise StopIteration

        self.last_id = items[items.count() - 1].id

        if self.values_fields:
            items = items.values(*self.values_fields)

        elif self.values_list_fields:
            items = items.values_list(*self.values_list_fields)

        return items

    def fetch(self):
        return iter(self)

    def set_filter(self, **kwargs):
        if self.filter:
            self.filter.update(kwargs)

        else:
            self.filter = kwargs

    def set_exclude_filter(self, **kwargs):
        if self.exclude_filter:
            self.exclude_filter.update(kwargs)

        else:
            self.exclude_filter = kwargs


class Service(ABC):
    model: models.Model
    serializer: serializers.ModelSerializer = serializers.ModelSerializer
    batch_fetcher: ServiceBatchFetch
    pk_name: str = 'id'
    pk_type: type = int

    def __init__(self, **kwargs):
        self.batch_fetcher = ServiceBatchFetch(model=self.model)
        self.serializer = kwargs.get('serializer', self.serializer)
        self.model = kwargs.get('model', self.model)
        self.pk_name = kwargs.get('pk_name', self.pk_name)
        self.pk_type = kwargs.get('pk_type', self.pk_type)

    def _segregate_data_for_create_or_update(self, data: list[dict]) -> \
            (list[dict], list[dict], list[models.Model]):
        pk_name = self.pk_name
        pk_type = self.pk_type
        filter_name = pk_name + '__in'
        all_ids = [element[pk_name] for element in data]
        all_objects = self.model.objects.filter(**{filter_name: all_ids})
        existing_objects = {getattr(item, pk_name): item for item
                            in all_objects}
        data_for_update = []
        data_for_create = []
        instances = []

        for item in data:
            instance = existing_objects.get(pk_type(item[pk_name]), None)
            if instance:
                data_for_update.append(item)
                instances.append(instance)

            else:
                data_for_create.append(item)

        return data_for_create, data_for_update, instances

    def _bulk_create(self, data: list[dict]) -> list[dict]:
        result = []

        if len(data) > 0:
            items = self.serializer(data=data, many=True)

            if items.is_valid(raise_exception=True):
                data_for_create = [self.model(**item) for item in
                                   items.validated_data]
                result = self.model.objects.bulk_create(data_for_create)
                result = [self.serializer(instance=item).data
                          for item in result]

        return result

    def _bulk_update(self, instances: list[models.Model],
                     fields: list[str] or None = None,
                     data: list[dict] or None = None,
                     raise_exception: bool = True) -> list:

        writable_fields = [field for field in self.serializer().fields
                           if
                           field not in self.serializer.Meta.read_only_fields
                           and field != self.pk_name]
        updated_instances = instances
        updated_fields = fields or writable_fields
        return_items = updated_instances

        if data and len(data) > 0:
            # В таком виде не работает:
            # {AttributeError}'list' object has no attribute 'pk'
            # items = self.serializer(instances, data=data, many=True,
            #                         partial=True)
            # if items.is_valid(raise_exception=True): #тут валится с ошибкой
            #     data_for_update = [self.model(**item) for item in
            #                        items.validated_data]
            #     self.model.objects.bulk_update(data_for_update)
            updated_instances = []
            return_items = []
            index = -1
            updated_fields = []
            now = timezone.now()

            for instance in instances:
                index += 1
                item_serializer = self.serializer(instance, data=data[index])

                if item_serializer.is_valid(raise_exception=raise_exception):
                    updated_fields = updated_fields or \
                                     [field for field in
                                      item_serializer.validated_data
                                      if field in writable_fields]
                    [setattr(instance, field,
                             item_serializer.validated_data[field])
                     for field in updated_fields]
                    instance.updatedAt = now
                    return_items.append(self.serializer(instance).data)
                    updated_instances.append(instance)

            updated_fields += ['updatedAt']

        self.model.objects.bulk_update(updated_instances, updated_fields,
                                       self.batch_fetcher.limit)

        return return_items

    def _bulk_delete(self, items: list[dict]):
        pk_name = self.pk_name
        pk_type = self.pk_type
        filter_name = pk_name + '__in'
        ids = [pk_type(item.get(self.pk_name)) for item in items]
        self.model.objects.filter(**{filter_name: ids}).delete()

        return True

    def create(self, data: dict or list) -> dict:
        with ServiceHandlerExceptions('service_class_create'):
            data = [data, ] if isinstance(data, dict) else data
            result = self._bulk_create(data)
            result = result[0] if isinstance(data, dict) else result

            return result

    def update(self, data: list[dict],
               fields: list[str] or None = None) -> list[dict]:
        with ServiceHandlerExceptions('service_class_update'):
            data = data if isinstance(data, list) else [data, ]
            data_for_create, data_for_update, instances = \
                self._segregate_data_for_create_or_update(data)
            result = self._bulk_update(instances, fields, data)
            result = result[0] if isinstance(data, dict) else result

            return result

    def upsert(self, data: list[dict]) -> list[dict]:
        with ServiceHandlerExceptions('service_class_upsert'):
            result = []
            data = data if isinstance(data, list) else [data, ]
            data_for_create, data_for_update, instances = \
                self._segregate_data_for_create_or_update(data)

            if len(data_for_create) > 0:
                result += self._bulk_create(data_for_create)

            if len(instances) > 0:
                result += self._bulk_update(instances, None, data_for_update)

            return result

    def delete(self, data: dict or list) -> bool:
        with ServiceHandlerExceptions('service_class_delete'):
            result = self._bulk_delete(data)

            return result

    def consume(self, payload: str) -> bool:
        data = json.loads(payload)
        result = bool(self.upsert(data))

        return result
