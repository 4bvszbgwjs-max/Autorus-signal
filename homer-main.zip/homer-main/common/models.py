from django.db import models
from import_export.admin import ImportExportModelAdmin


class CoreModel(models.Model):
    # region Fields:
    id = models.AutoField(
        verbose_name='ID',
        help_text='Цифровой уникальный идентификатор записи',
        primary_key=True,
        db_column='id',
    )
    createdAt = models.DateTimeField(
        verbose_name='Создано',
        help_text='Дата и время создания записи',
        auto_now_add=True,
    )
    updatedAt = models.DateTimeField(
        verbose_name='Изменено',
        help_text='Дата и время изменения записи',
        auto_now=True,
    )
    isDeleted = models.BooleanField(
        verbose_name='Пометка удаления',
        help_text='Признак удаления записи',
        default=False
    )
    # endregion

    list_filter = ('isDeleted', 'createdAt', 'updatedAt',)
    search_fields = ('id', 'createdAt', 'updatedAt',)
    readonly_fields = ('__str__', 'id', 'createdAt', 'updatedAt', )

    class Meta:
        abstract = True
        get_latest_by = ['updatedAt']


class CoreModelAdmin(ImportExportModelAdmin):
    service_fields = ('Служебные', {
        'fields': ('id', 'createdAt', 'updatedAt', 'isDeleted',),
    })

    list_filter = CoreModel.list_filter
    search_fields = CoreModel.search_fields
    readonly_fields = CoreModel.readonly_fields
