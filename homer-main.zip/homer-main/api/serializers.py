from drf_spectacular.utils import extend_schema_serializer
from eventlog.models import Event
from rest_framework import serializers, pagination
from rest_framework.response import Response


def enveloper(serializer_class, paginate=False):
    serializer_name = serializer_class.__name__.replace('Serializer', '')
    postfix = 'Paginate' if paginate else ''
    component_name = f'Enveloped{serializer_name}{postfix}'

    class Meta(serializers.Serializer):
        total = serializers.IntegerField()
        limit = serializers.IntegerField()
        page = serializers.IntegerField()

    @extend_schema_serializer(many=False, component_name=component_name)
    class EnvelopeSerializer(serializers.Serializer):
        if paginate:
            meta_class = type(serializer_name + 'Meta', (Meta,), {})

        else:
            meta_class = serializers.JSONField

        meta = meta_class()
        data = serializer_class(many=paginate)

    return EnvelopeSerializer


class Pagination(pagination.PageNumberPagination):
    page_size_query_param = 'limit'

    def get_paginated_response(self, data):
        return Response({
            'meta': {
                'total': self.page.paginator.count,
                'limit': self.page_size,
                'page': self.page.number
            },
            'data': data
        })

    def get_paginated_response_schema(self, schema):
        return {
            'type': 'object',
            'properties': {
                'count': {
                    'type': 'integer',
                    'example': 123,
                },
                'data': schema,
                'meta': {
                    'type': 'object',
                    'properties': {
                        'total': {
                            'type': 'integer',
                            'example': 123,
                        },
                        'limit': {
                            'type': 'integer',
                            'example': 123,
                        },
                        'page': {
                            'type': 'integer',
                            'example': 123,
                        },
                    },
                },
            },
        }


class PingSerializer(serializers.Serializer):
    ...


class EventlogSerializer(serializers.ModelSerializer):
    class Meta:
        model = Event
        exclude = ['level']
