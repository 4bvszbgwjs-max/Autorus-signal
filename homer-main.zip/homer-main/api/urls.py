from django.urls import include, re_path

from api.v1.router import api_v1_router

urlpatterns = [
    re_path(r'^v1/?', include(api_v1_router.urls), name='api_v1'),
]
