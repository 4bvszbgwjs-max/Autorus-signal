from drf_spectacular.utils import extend_schema
from eventlog.models import Event
from rest_framework import serializers
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.viewsets import ReadOnlyModelViewSet

from api.filters import EventlogFilter
from api.serializers import enveloper, EventlogSerializer


class PingSerializer(serializers.Serializer):  # noqa
    ...


class PingView(APIView):
    """
    Проверка работоспособности сервиса
    """
    serializer_class = PingSerializer

    @staticmethod
    def get(request):
        return Response()


@extend_schema(responses=enveloper(EventlogSerializer), tags=['eventlog'])
class EventlogViewSet(ReadOnlyModelViewSet):
    """
    Журнал событий
    """
    queryset = Event.objects.all()
    serializer_class = EventlogSerializer
    filterset_class = EventlogFilter
    paginated_actions = ('list',)

    @extend_schema(responses=enveloper(EventlogSerializer, True))
    def list(self, request, *args, **kwargs):
        return super().list(self, request, *args, **kwargs)
