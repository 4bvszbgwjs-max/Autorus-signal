from django_filters import rest_framework as filters
from eventlog.models import Event


class EventlogFilter(filters.FilterSet):
    timestamp = filters.IsoDateTimeFromToRangeFilter()

    class Meta:
        model = Event
        fields = ('id', 'initiator', 'timestamp', 'level', 'event', 'tracing')
