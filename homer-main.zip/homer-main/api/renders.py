import sys

import django.core.exceptions as django_exceptions
import rest_framework.exceptions as drf_exceptions
from rest_framework.renderers import JSONRenderer
from rest_framework.serializers import as_serializer_error
from rest_framework.utils import json
from rest_framework.views import exception_handler


def _get_full_details(details, source=''):
    if isinstance(details, list):
        return [_get_full_details(detail, source) for detail in details]

    elif isinstance(details, dict):
        return [_get_full_details(detail, source) for source, detail in
                details.items()]

    return {
        'code': details.code,
        'source': source,
        'message': details
    }


def exceptions_handler(exc, context):
    response = exception_handler(exc, context)

    if response is None:
        status_code = 500

        if isinstance(exc, django_exceptions.ValidationError):
            api_exception = drf_exceptions.ValidationError(
                detail=as_serializer_error(exc))
            status_code = 400

        else:
            exc_type, exc_value, tb = sys.exc_info()
            error_detail = drf_exceptions.ErrorDetail(str(exc_value),
                                                      code='unknown')
            detail = {str(exc_type): error_detail}
            api_exception = drf_exceptions.APIException(detail=detail)

        response = exception_handler(api_exception, context)
        response.status_code = status_code

    return response


class ResponseRenderer(JSONRenderer):
    charset = 'utf-8'

    def render(self, data, accepted_media_type=None, renderer_context=None):
        response_data = {}
        response = renderer_context.get('response', {})
        renderer_context = renderer_context or {}
        view = renderer_context.get('view', {})
        detail = False if not view else getattr(view, 'detail', False)
        view_name = view and getattr(view, 'action', '')
        paginated_actions = view and getattr(view, 'paginated_actions', [])
        is_paginated = view_name in paginated_actions
        empty_data = {} if detail else []

        if response.exception:
            errors = []
            if isinstance(data, dict):
                for source, detail in data.items():
                    error = _get_full_details(detail, source)

                    if isinstance(error, list):
                        errors.extend(error)

                    else:
                        errors.append(error)

            response_data = {'errors': errors}

        elif is_paginated:
            response_data = data

        else:
            response_data['meta'] = {}
            response_data['data'] = data or empty_data

        return json.dumps(response_data, ensure_ascii=False)
