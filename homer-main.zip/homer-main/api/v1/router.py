from rest_framework.routers import SimpleRouter

from api.views import EventlogViewSet
from notifications.views import ChannelViewSet, MessageViewSet, \
    SendingViewSet, ScenarioViewSet
from recipients.views import RecipientViewSet

api_v1_router = SimpleRouter()
api_v1_router.trailing_slash = '/?'
api_v1_router.register(r'channel', ChannelViewSet)
api_v1_router.register(r'message', MessageViewSet)
api_v1_router.register(r'sending', SendingViewSet)
api_v1_router.register(r'recipient', RecipientViewSet)
api_v1_router.register(r'eventlog', EventlogViewSet)
api_v1_router.register(r'scenario', ScenarioViewSet)
