import os

from celery import Celery
from celery.signals import setup_logging
from celery.utils.log import get_task_logger
from kombu import Queue

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
app = Celery('homer')
app.config_from_object('django.conf:settings', namespace='CELERY')


@setup_logging.connect
def config_loggers(*args, **kwags):
    from logging.config import dictConfig
    from django.conf import settings
    dictConfig(settings.LOGGING)


app.autodiscover_tasks()
logger = get_task_logger(__name__)

app.conf.task_ignore_result = True
app.conf.task_default_queue = 'arus.homer.main'
app.conf.task_default_exchange = 'homer'
app.conf.task_default_routing_key = 'task.default'
app.conf.task_queues = [
    Queue('arus.homer.main', routing_key='task.#', ),
    Queue('arus.homer.mail.send', routing_key='mail.send.#'),
    Queue('arus.homer.sms.send', routing_key='sms.send.#'),
    Queue('arus.homer.push.send', routing_key='push.send.#'),
    Queue('arus.homer.telegram.send', routing_key='telegram.send.#'),
    Queue('arus.homer.notices.send', routing_key='notices.send.#'),
]
app.conf.task_routes = (
    [
        ('notifications.tasks.task_send_mail',
         {'queue': 'arus.homer.mail.send'}),
        ('notifications.tasks.task_send_sms',
         {'queue': 'arus.homer.sms.send'}),
        ('notifications.tasks.task_send_push',
         {'queue': 'arus.homer.push.send'}),
        ('notifications.tasks.task_send_telegram',
         {'queue': 'arus.homer.telegram.send'}),
        ('notifications.tasks.task_send_notices',
         {'queue': 'arus.homer.notices.send'}),
    ],
)
