import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
LOG_PATH = os.path.join(BASE_DIR, 'logs')
DEFAULT_AUTO_FIELD = 'django.db.models.AutoField'
SECRET_KEY = os.environ.get('SECRET_KEY')
DEBUG = True if os.environ.get('DEBUG') == 'True' else False
ALLOWED_HOSTS = os.environ.get("ALLOWED_HOSTS").split(",")
DB_NAME = os.environ.get('POSTGRES_DB')
DB_USER = os.environ.get('POSTGRES_USER')
DB_PASSWORD = os.environ.get('POSTGRES_PASSWORD')
DB_HOST = os.environ.get('POSTGRES_HOST')
DB_PORT = os.environ.get('POSTGRES_PORT')
DJANGO_SUPERUSER_USERNAME = os.environ.get('DJANGO_SUPERUSER_USERNAME')
DJANGO_SUPERUSER_PASSWORD = os.environ.get('DJANGO_SUPERUSER_PASSWORD')
DJANGO_SUPERUSER_EMAIL = os.environ.get('DJANGO_SUPERUSER_EMAIL')
DJANGO_LOG_LEVEL = os.environ.get('DJANGO_LOG_LEVEL', 'ERROR')
CELERY_LOG_LEVEL = os.environ.get('CELERY_LOG_LEVEL', 'ERROR')
ARUS_UT_SERVER = os.environ.get('ARUS_UT_SERVER')
ARUS_UT_PARTNER_SEGMENTS_RESOURCE = \
    os.environ.get('ARUS_UT_PARTNER_SEGMENTS_RESOURCE')
ARUS_UT_PARTNER_SEGMENTS_PARTNERS_RESOURCE = \
    os.environ.get('ARUS_UT_PARTNER_SEGMENTS_PARTNERS_RESOURCE')
ARUS_UT_USER = os.environ.get('ARUS_UT_USER')
ARUS_UT_PASSWORD = os.environ.get('ARUS_UT_PASSWORD')

# Application definition

INSTALLED_APPS = [
    'jazzmin',
    'eventlog',
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'rest_framework',
    'django_filters',
    'corsheaders',
    'db_mutex',
    'recipients',
    'notifications',
    'drf_spectacular',
    'django_jsonform',
    'import_export',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'config.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates']
        ,
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'config.wsgi.application'

DATABASES = {
    'default': {
        "ENGINE": 'django.db.backends.postgresql_psycopg2',
        'NAME': DB_NAME,
        'USER': DB_USER,
        'PASSWORD': DB_PASSWORD,
        'HOST': DB_HOST,
        'PORT': DB_PORT,
        'CONN_MAX_AGE': 0,
    }
}

AUTH_PASSWORD_VALIDATORS = []

LANGUAGE_CODE = 'ru-ru'

TIME_ZONE = 'Europe/Moscow'

USE_I18N = True

USE_L10N = True

USE_TZ = True

STATIC_URL = '/static/'

STATICFILES_DIRS = (os.path.join(BASE_DIR, 'static'),)

STATIC_ROOT = os.path.join(BASE_DIR, 'live-static', 'static-root')

MEDIA_URL = '/media/'

MEDIA_ROOT = os.path.join(BASE_DIR, 'live-static', 'media-root')

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'verbose': {
            'format': '%(levelname)s %(asctime)s %(name)s.%(funcName)s:%('
                      'lineno)s- %(message)s',
        },
        'simple': {
            'format': '{levelname} {message}',
            'style': '{',
        },
    },
    'handlers': {
        'eventlog': {
            'class': 'eventlog.services.EventLogHandler'
        },
        'console': {
            'class': 'logging.StreamHandler',
            'formatter': 'simple',
        },
        'file': {
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': os.path.join(LOG_PATH, 'homer.log'),
            'maxBytes': 1024 * 1024 * 100,  # 100 mb
            'backupCount': 10,
            'formatter': 'verbose',
        },
    },
    'loggers': {
        'root': {
            'handlers': ['file', 'console', 'eventlog'],
            'level': DJANGO_LOG_LEVEL,
        },
        'celery': {
            'handlers': ['file', 'console', 'eventlog', ],
            'level': CELERY_LOG_LEVEL,
        },
    }
}

REST_FRAMEWORK = {
    'DEFAULT_RENDERER_CLASSES': ('api.renders.ResponseRenderer',),
    'EXCEPTION_HANDLER': 'api.renders.exceptions_handler',
    'DEFAULT_PAGINATION_CLASS': 'api.serializers.Pagination',
    'PAGE_SIZE': 100,
    'DEFAULT_SCHEMA_CLASS': 'drf_spectacular.openapi.AutoSchema',
    'TEST_REQUEST_DEFAULT_FORMAT': 'json',
    'DEFAULT_FILTER_BACKENDS': [
        'django_filters.rest_framework.DjangoFilterBackend'],
}

SPECTACULAR_SETTINGS = {
    'TITLE': 'Homer API',
    'DESCRIPTION': 'API for notifications service "Homer"',
    'VERSION': '0.0.1',
    'RENDERER_WHITELIST': ['api.renders.ResponseRenderer'],
}

CORS_ALLOW_ALL_ORIGINS = True
CORS_ALLOW_CREDENTIALS = True

# Celery Configuration Options
CELERY_TIMEZONE = TIME_ZONE
CELERY_TASK_TIME_LIMIT = 30 * 60
CELERY_BROKER_URL = os.environ.get('CELERY_BROKER_URL')

# rmq Configuration Options
RMQ_BROKER_URL = os.environ.get('RMQ_BROKER_URL')
RMQ_CREATE_MESSAGE_EXCHANGE = os.environ.get('RMQ_CREATE_MESSAGE_EXCHANGE')

JAZZMIN_SETTINGS = {
    # title of the window (Will default to current_admin_site.site_title if absent or None)
    'site_title': 'Homer',
    # Title on the brand, and login screen (19 chars max) (defaults to current_admin_site.site_header if absent or None)
    'site_header': 'Homer',
    # square logo to use for your site, must be present in static files, used for favicon and brand on top left
    'site_logo': 'images/homer64c.png',
    # Welcome text on the login screen
    'welcome_sign': 'Сервер рассылок',
    # Copyright on the footer
    'copyright': 'Autorus Ltd',
    # The model admin to search from the search bar, search bar omitted if excluded
    'search_model': 'notifications.Message',
    # Field name on user model that contains avatar image
    'user_avatar': '',
    ############
    # Top Menu #
    ############
    # Links to put along the top menu
    'topmenu_links': [
        # Url that gets reversed (Permissions can be added)
        # {'model': 'eventlog.Event'},
    ],
    #############
    # User Menu #
    #############
    # Additional links to include in the user menu on the top right ('app' url type is not allowed)
    'usermenu_links': [],
    #############
    # Side Menu #
    #############
    # Whether to display the side menu
    'show_sidebar': True,
    # Whether to aut expand the menu
    'navigation_expanded': True,
    # Hide these apps when generating side menu e.g (auth)
    'hide_apps': [],
    # Hide these models when generating side menu (e.g auth.user)
    'hide_models': [],
    # List of apps to base side menu (app or model) ordering off of
    'order_with_respect_to': [
        'recipients', 'recipients.Recipient',
        'notifications', 'eventlog', 'auth',
        'notifications.Channels', 'notifications.Message',
        'notifications.Sending', 'notifications.Scenario',
    ],
    # Custom links to append to app groups, keyed on app name
    'custom_links': {},
    # Custom icons for side menu apps/models See https://fontawesome.com/icons?d=gallery&m=free
    # for a list of icon classes
    'icons': {
        'auth': 'fas fa-users-cog',
        'auth.user': 'fas fa-user',
        'auth.Group': 'fas fa-users',
        'admin.LogEntry': 'fas fa-file',
        'notifications': 'fas fa-tasks',
        'notifications.Message': 'fas fa-envelope',
        'notifications.Sending': 'fas fa-paper-plane',
        'eventlog.Event': 'fas fa-history',
        'notifications.Channel': 'fas fa-satellite-dish',
        'recipients.Recipient': 'fas fa-address-card',
        'notifications.Scenario': 'fas fa-film',
    },
    # Icons that are used when one is not manually specified
    'default_icon_parents': 'fas fa-chevron-circle-right',
    'default_icon_children': 'fas fa-circle',
    #################
    # Related Modal #
    #################
    # Activate Bootstrap modal
    'related_modal_active': False,
    #############
    # UI Tweaks #
    #############
    # Relative paths to custom CSS/JS scripts (must be present in static files)
    'custom_css': 'css/app-style.css',
    'custom_js': 'js/app-scripts.js',
    # Whether to show the UI customizer on the sidebar
    'show_ui_builder': False,
    ###############
    # Change view #
    ###############
    # Render out the change view as a single form, or in tabs, current options are
    # - single
    # - horizontal_tabs (default)
    # - vertical_tabs
    # - collapsible
    # - carousel
    'changeform_format': 'horizontal_tabs',
    # override change forms on a per modeladmin basis
    'changeform_format_overrides': {},
    # Add a language dropdown into the admin
    'language_chooser': False,
}

JAZZMIN_UI_TWEAKS = {
    'navbar_small_text': False,
    'footer_small_text': False,
    'body_small_text': False,
    'brand_small_text': False,
    'brand_colour': 'navbar-primary',
    'accent': 'accent-primary',
    'navbar': 'navbar-primary navbar-dark',
    'no_navbar_border': True,
    'navbar_fixed': False,
    'layout_boxed': False,
    'footer_fixed': False,
    'sidebar_fixed': False,
    'sidebar': 'sidebar-light-primary',
    'sidebar_nav_small_text': False,
    'sidebar_disable_expand': False,
    'sidebar_nav_child_indent': False,
    'sidebar_nav_compact_style': False,
    'sidebar_nav_legacy_style': False,
    'sidebar_nav_flat_style': False,
    'theme': 'default',
    'dark_mode_theme': None,
    'button_classes': {
        'primary': 'btn-outline-primary',
        'secondary': 'btn-outline-secondary',
        'info': 'btn-outline-info',
        'warning': 'btn-outline-warning',
        'danger': 'btn-outline-danger',
        'success': 'btn-outline-success'
    }
}
