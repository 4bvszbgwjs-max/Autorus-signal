import re

from django.conf import settings
from django.contrib import admin
from django.urls import re_path, include
from django.views.generic import RedirectView
from django.views.static import serve
from drf_spectacular.views import SpectacularAPIView

from api.views import PingView
from common import metrics

admin.site.site_title = 'Homer'
admin.site.site_header = 'Homer'
admin.site.index_title = 'Администрирование'
admin.site.enable_nav_sidebar = True
static_urls = re_path(
    r'^%s(?P<path>.*)$' % re.escape(settings.STATIC_URL.lstrip('/')),
    serve,
    {'document_root': settings.STATIC_ROOT}
)

urlpatterns = [
    static_urls,
    re_path(r'^admin/?', admin.site.urls),
    re_path(r'^$', RedirectView.as_view(url='admin/')),
    re_path(r'^favicon\.ico$',
            RedirectView.as_view(url='/static/images/favicon.ico')),
    re_path(r"^metrics$", metrics.export_to_django_view, name='metrics'),
    re_path(r'^api/?', include('api.urls')),
    re_path(r'^ping/?', PingView.as_view(), name='ping'),
    re_path(r'^openapi/?', SpectacularAPIView.as_view(), name='openapi'),
]
