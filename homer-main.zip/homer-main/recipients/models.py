from django.db import models

from common import CoreModel


class Recipient(CoreModel):
    # region Fields:...

    name = models.CharField(
        verbose_name='Наименование',
        help_text='ФИО получателя',
        max_length=200,
        blank=True,
        null=True,
        default=''
    )
    phone = models.CharField(
        verbose_name='Телефон',
        help_text='Телефон получателя. Поле уникально и не может быть пустым',
        max_length=200,
        blank=False,
        unique=True,
    )
    email = models.CharField(
        verbose_name='Эл. почта',
        help_text='Адрес электронной почты получателя',
        max_length=200,
        blank=True,
        null=True,
        default='',
    )
    applicationFirebaseToken = models.CharField(
        verbose_name='Firebase токен',
        help_text='Токен для отправки push уведомлений',
        max_length=200,
        null=True,
        blank=True,
        default='',
    )
    isSubscribe = models.BooleanField(
        verbose_name='Согласен на получение рассылок',
        help_text='Признак согласия получателя на получение рассылок.'
                  ' Может игнорироваться в некоторых сценариях отправки',
        blank=True,
        null=True,
        default=False,
    )
    isConfirmed = models.BooleanField(
        verbose_name='Email подтвержден',
        help_text='Признак проверенности электронной почты',
        blank=True,
        null=True,
        default=False,
    )
    isPhoneConfirmed = models.BooleanField(
        verbose_name='Телефон подтвержден',
        help_text='Признак проверенности номера телефона',
        blank=True,
        null=True,
        default=False,
    )
    # endregion

    list_filter = CoreModel.list_filter
    search_fields = CoreModel.search_fields + ('phone', 'email', 'name',
                                               'applicationFirebaseToken', )

    class Meta:
        db_table = 'recipients'
        verbose_name = 'Получатель'
        verbose_name_plural = 'Получатели'
        indexes = [models.Index(fields=['phone', ]), ]

    def __str__(self):
        return f'{self.phone} ({self.name})'
