from django.test import TestCase
from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase

from recipients.models import Recipient
from recipients.services import RecipientService

recipient = {
    'id': 100,
    'createdAt': '2022-12-16T10:43:27.159Z',
    'updatedAt': '2022-12-16T11:07:03.189Z',
    'isDeleted': False,
    'name': 'Ivanov Ivan',
    'phone': '+70123456789',
    'email': 'test@email.ru',
    'applicationFirebaseToken': 'string',
    'isSubscribe': True,
    'isConfirmed': True,
    'isPhoneConfirmed': True
}

recipient_update = {
    'id': 100,
    'createdAt': '2022-12-16T10:43:27.159Z',
    'updatedAt': '2022-12-16T11:07:03.189Z',
    'isDeleted': False,
    'name': 'Ivanov Ivan',
    'phone': '+70123456789',
    'email': 'test@email.ru',
    'applicationFirebaseToken': 'string',
    'isSubscribe': False,
    'isConfirmed': True,
    'isPhoneConfirmed': True
}


class RecipientTest(TestCase):
    fixtures = ['initial_data.json']

    def setUp(self):
        self.model = Recipient
        self.data_for_create = recipient
        self.data_for_update = recipient_update
        self.fields = [field.name for field in self.model._meta.get_fields()
                  if not field.auto_created and not field.is_relation
                       and field.name not in self.model.readonly_fields]
        self.item = self.model.objects.create(**self.data_for_create)
        self.item.save()

    def tearDown(self):
        self.item.delete()

    def test_read_model(self):
        [self.assertEqual(getattr(self.item, field),
                        self.data_for_create[field]) for field in self.fields]

    def test_update_model(self):
        [setattr(self.item, field, self.data_for_update[field])
         for field in self.fields]
        self.item.save()
        [self.assertEqual(getattr(self.item, field),
                        self.data_for_update[field]) for field in self.fields]


class APITestRecipient(APITestCase):
    fixtures = ['initial_data.json']

    def test_api_recipient_create(self):
        response = self.client.post(reverse('recipient-list'), recipient)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_api_recipient_update(self):
        response = self.client.put(reverse('recipient-detail', args=[1]),
                                   data=recipient_update)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_api_recipient_partial_update(self):
        response = self.client.patch(reverse('recipient-detail', args=[1]),
                                     data={'isSubscribe': False})
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_api_recipient_bulk_upsert(self):
        response = self.client.patch(reverse('recipient-bulk-upsert'),
                                     data=[recipient_update])
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_api_recipient_list_phone(self):
        response = self.client.patch(reverse('recipient-list-phone'))
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_api_recipient_read(self):
        response = self.client.get(reverse('recipient-detail', args=[1]))
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_api_recipient_list(self):
        response = self.client.get(reverse('recipient-list'))
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_api_recipient_delete(self):
        response = self.client.delete(
            reverse(
                'recipient-detail',
                args=[1]
            )
        )
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)


class RecipientServiceTest(TestCase):
    fixtures = ['initial_data.json']

    def setUp(self):
        self.service = RecipientService
        self.recipient1 = Recipient.objects.get(pk=1)
        self.recipient2 = Recipient.objects.get(pk=2)

    def test_get_pk_map(self):
        recipient_ids = [self.recipient1.phone, self.recipient2.phone]
        recipients_map = {
            self.recipient1.phone: self.service.model.objects.get(pk=1),
            self.recipient2.phone: self.service.model.objects.get(pk=2),
        }
        result = self.service.get_pk_map(recipient_ids)
        self.assertEqual(recipients_map, result)
