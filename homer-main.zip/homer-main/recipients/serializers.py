from rest_framework import serializers

from common import CoreModel
from recipients.models import Recipient


class RecipientSerializer(serializers.ModelSerializer):
    class Meta:
        model = Recipient
        read_only_fields = CoreModel.readonly_fields
        fields = '__all__'
        extra_kwargs = {'id': {'read_only': False}}
