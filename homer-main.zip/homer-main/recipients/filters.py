from common.filters import CoreFilter
from recipients.models import Recipient


class RecipientFilter(CoreFilter):
    class Meta:
        model = Recipient
        fields = Recipient.search_fields
