from django.contrib import admin

from common import CoreModelAdmin
from recipients.models import *


@admin.register(Recipient)
class RecipientAdmin(CoreModelAdmin):
    list_display = ('__str__', 'createdAt', 'updatedAt')
    fieldsets = (
        ('Основное', {
            'fields': ('name', 'phone', 'isPhoneConfirmed',
                       'email', 'isConfirmed',
                       'applicationFirebaseToken', 'isSubscribe',)
        }), CoreModelAdmin.service_fields,
    )
    readonly_fields = CoreModelAdmin.readonly_fields
    list_filter = Recipient.list_filter
    search_fields = Recipient.search_fields
