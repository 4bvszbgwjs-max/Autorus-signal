from common.services import Service
from recipients.models import Recipient
from recipients.serializers import RecipientSerializer


class RecipientService(Service):
    model = Recipient
    serializer = RecipientSerializer
    pk_name = 'phone'
    pk_type = str

    @classmethod
    def get_pk_map(cls, recipient_ids: list) -> dict[Recipient]:
        """
        Функция для получения словаря получателей
        :param recipient_ids: Список идентификаторов получателей
        :return: Словарь, где ключ - это идентификатор получателя,
                значение - экземпляр класса Recipient
        """
        filter_name = cls.pk_name + '__in'
        recipients = cls.model.objects.filter(**{filter_name: recipient_ids})
        recipients = {item.phone: item for item in recipients}

        return recipients
