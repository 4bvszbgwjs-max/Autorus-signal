from drf_spectacular.utils import extend_schema
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet

from api.serializers import enveloper
from recipients.filters import RecipientFilter
from recipients.models import Recipient
from recipients.serializers import RecipientSerializer
from recipients.services import RecipientService


@extend_schema(responses=enveloper(RecipientSerializer), tags=['recipient'])
class RecipientViewSet(ModelViewSet):
    """
    Работа с получателями
    """
    queryset = Recipient.objects.all()
    serializer_class = RecipientSerializer
    filterset_class = RecipientFilter
    service_class = RecipientService
    paginated_actions = ('list', 'list_phone')

    @extend_schema(responses=enveloper(RecipientSerializer, True))
    def list(self, request, *args, **kwargs):
        return super().list(self, request, *args, **kwargs)

    @action(detail=False, methods=['patch'], url_path='bulk/upsert')
    def bulk_upsert(self, request):
        result_data = self.service_class().upsert(request.data)

        return Response(data=result_data)

    @extend_schema(responses=enveloper(RecipientSerializer, True))
    @action(detail=False, methods=['patch'], url_path='list/phone')
    def list_phone(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset())
        page = self.paginate_queryset(queryset)

        if page is not None:
            serializer = self.get_serializer(page, many=True)
            data = [item['phone'] for item in serializer.data]

            return self.get_paginated_response(data)

        return Response([])
